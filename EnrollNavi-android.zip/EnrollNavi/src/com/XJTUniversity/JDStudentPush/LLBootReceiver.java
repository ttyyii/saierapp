package com.XJTUniversity.JDStudentPush;

import android.app.ActivityManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * Created by vincent on 2014/7/1.<br/>
 * 描述: TODO
 */
public class LLBootReceiver extends BroadcastReceiver {
  @Override public void onReceive(Context context, Intent intent) {
    if (intent.getAction().equals(Intent.ACTION_TIME_TICK)) {
      boolean isRunning = false;
      ActivityManager manager =
          (ActivityManager) context.getSystemService(Context.ACTIVITY_SERVICE);
      for (ActivityManager.RunningServiceInfo service : manager.getRunningServices(
          Integer.MAX_VALUE)) {
        if ("com.XJTUniversity.JDStudentPush.LocationService".equals(
            service.service.getClassName())) {
          isRunning = true;
        }
      }
      System.out.println("LocationService is not running,then will open ....");
      if (!isRunning) {
        Intent serviceIntent = new Intent(context, LLLocationService.class);
        context.startService(serviceIntent);
      }
    }
  }
}
