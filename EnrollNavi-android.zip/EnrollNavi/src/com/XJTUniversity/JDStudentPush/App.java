package com.XJTUniversity.JDStudentPush;

import android.app.Application;
import android.content.Intent;
import android.content.IntentFilter;
import android.widget.Toast;
import cn.jpush.android.api.JPushInterface;

import com.XJTUniversity.JDStudentPush.util.RequestManager;
import com.baidu.location.GeofenceClient;
import com.baidu.location.LocationClient;
import com.baidu.mapapi.SDKInitializer;

/**
 * Created by vincent on 2014/6/18.<br/>
 */
public class App extends Application {

  public static String NET_ID = "";

  public static boolean isRefresh = false;

  public static final String AUTO_LOGIN = "auto_login";

  public static final String REM_PWD = "rem_pwd";

  public static final String UNAME = "username";

  public static final String PWD = "password";

  public LocationClient mBDLocationClient;

  public GeofenceClient mGeoFenceClient;

  @Override public void onCreate() {
    super.onCreate();

    SDKInitializer.initialize(getApplicationContext());
    mGeoFenceClient = new GeofenceClient(getApplicationContext());
    mBDLocationClient = new LocationClient(getApplicationContext());
    initRequestQueueManager();
    JPushInterface.init(getApplicationContext());

    IntentFilter filter = new IntentFilter(Intent.ACTION_TIME_TICK);
    LLBootReceiver receiver = new LLBootReceiver();
    registerReceiver(receiver,filter);

      Thread.setDefaultUncaughtExceptionHandler(new Thread.UncaughtExceptionHandler() {
        @Override
        public void uncaughtException(Thread thread, Throwable ex) {
          ex.printStackTrace();
          Intent intent = getPackageManager().getLaunchIntentForPackage(getPackageName());
          startActivity(intent);
          Toast.makeText(App.this, "程序发生异常", Toast.LENGTH_SHORT).show();
          System.exit(-1);
        }
      });

  }

  private void initRequestQueueManager(){
    RequestManager.init(getApplicationContext());
  }
}
