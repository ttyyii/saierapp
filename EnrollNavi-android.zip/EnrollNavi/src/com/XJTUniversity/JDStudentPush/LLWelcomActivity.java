package com.XJTUniversity.JDStudentPush;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.Window;
import android.view.WindowManager;

/**
 * Created by vincent on 2014/7/2.<br/>
 * 描述: TODO
 */
public class LLWelcomActivity extends Activity {

  private Handler mHandler = new Handler();

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN,
        WindowManager.LayoutParams.FLAG_FULLSCREEN);
    setContentView(R.layout.ll_activity_welcome);

    //启动定位服务
    Intent locationService = new Intent(this, LLLocationService.class);
    startService(locationService);

    mHandler.postDelayed(new Runnable() {
      @Override public void run() {
        Intent intent = new Intent(LLWelcomActivity.this, LLLoginActivity.class);
        startActivity(intent);
        finish();
      }
    }, 3000L);
  }

}
