package com.XJTUniversity.JDStudentPush.util;

import java.util.HashMap;

/**
 * Created by vincent on 2014/6/23.<br/>
 * 描述: TODO
 */
public class ApiParams extends HashMap<String, String> {

  public ApiParams with(String key, String value) {
    put(key, value);
    return this;
  }
}
