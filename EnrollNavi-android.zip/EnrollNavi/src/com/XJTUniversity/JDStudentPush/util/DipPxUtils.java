package com.XJTUniversity.JDStudentPush.util;

import android.content.Context;

public class DipPxUtils {
	
	public static int dpToPx(Context context, float dp) {
		if (context == null) {
			return -1;
		}
		return (int) (dp * context.getResources().getDisplayMetrics().density);
	}

	public static int pxToDp(Context context, float px) {
		if (context == null) {
			return -1;
		}
		return (int) (px / context.getResources().getDisplayMetrics().density);
	}

	public static int dpToPxInt(Context context, float dp) {
		return (int) (dpToPx(context, dp) + 0.5f);
	}

}
