package com.XJTUniversity.JDStudentPush.util;

/**
 * Created by vincent on 2014/6/23.<br/>
 * 描述: 接口地址
 */
public class Api {

  private static final String BASE_URL = "http://202.117.1.206:8099/";
  //private static final String BASE_URL = "http://192.168.1.109:8080/";

  public static final String USER_CHECK_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/userInfo/gerUserInfo/%s.json\n";

  public static final String LOGIN_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/userInfo/userLogin/%s/%s.json";

  public static final String REG_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/userInfo/userReg/%s/%s.json";

  public static final String UPDATE_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/userInfo/updateUser/%s/%s.json";

  public static final String MSG_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/information/informations/%s/%s/%s.json";

  public static final String CAMPUS_MAP_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/campusMap/campusMaps/%s.json";

  /** Message type=3 */
  public static final String CAMPUS_INFO_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/information/campusInfos/%s/%s.json";

  /** Message type=4 */
  public static final String ROUTE_INFO_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/information/routesInfo/%s/%s.json";

  /** 基于地理位置消息推送 */
  public static final String MSG_PUSH_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/information/pushInfo4/%s/%s.json";

  public static final String IN_CAMPUS_MSG_URL =
      BASE_URL + "SchoolReportGuide/rest/rest/information/pushInfoType3/%s.json";

  public static final String MSG_TYPE_FIVE_URL = BASE_URL+"SchoolReportGuide/rest/rest/information/reportMaps5/%s.json";

  /**是否已读 infoID/NetID**/
  public static final String MSG_READ_URL = BASE_URL+"SchoolReportGuide/rest/rest/information/infoRead/%s/%s.json";

  /**消息删除 infoID/NetId**/
  public static final String DELETE_MSG_URL = BASE_URL + "SchoolReportGuide/rest/rest/information/deleteInfo/%s/%s.json";
}
