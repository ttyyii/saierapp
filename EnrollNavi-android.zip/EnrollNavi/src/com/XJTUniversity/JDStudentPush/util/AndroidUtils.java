package com.XJTUniversity.JDStudentPush.util;

import android.content.Context;
import android.telephony.TelephonyManager;
import android.util.Log;
import com.XJTUniversity.JDStudentPush.R;
import com.XJTUniversity.JDStudentPush.widget.CustomProgressDialog;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Created by vincent on 2014/6/24.<br/>
 * 描述: TODO
 */
public class AndroidUtils {

  public static int[] resIds = new int[] {
      R.drawable.ll_pin_shuzi_01, R.drawable.ll_pin_shuzi_02, R.drawable.ll_pin_shuzi_03,
      R.drawable.ll_pin_shuzi_04, R.drawable.ll_pin_shuzi_05, R.drawable.ll_pin_shuzi_06,
      R.drawable.ll_pin_shuzi_07, R.drawable.ll_pin_shuzi_08, R.drawable.ll_pin_shuzi_09,
      R.drawable.ll_pin_shuzi_10,R.drawable.ll_pin_jiaoda02
  };

  public static int[] resIds_clicked = new int[] {
      R.drawable.ll_pin_shuzi_lv_01, R.drawable.ll_pin_shuzi_lv_02, R.drawable.ll_pin_shuzi_lv_03,
      R.drawable.ll_pin_shuzi_lv_04, R.drawable.ll_pin_shuzi_lv_05, R.drawable.ll_pin_shuzi_lv_06,
      R.drawable.ll_pin_shuzi_lv_07, R.drawable.ll_pin_shuzi_lv_08, R.drawable.ll_pin_shuzi_lv_09,
      R.drawable.ll_pin_shuzi_lv_10,R.drawable.ll_pin_jiaoda01
  };

  public static int[] campus_icon = new int[] {
      R.drawable.ll_pin_bank02, R.drawable.ll_pin_bathroom02, R.drawable.ll_pin_boilingwaterroom02,
      R.drawable.ll_pin_schoolgate02, R.drawable.ll_pin_canteen02, R.drawable.ll_pin_library02,
      R.drawable.ll_pin_dorm02,R.drawable.ll_pin_jianzhu02,R.drawable.ll_pin_yiyuan02, R.drawable.ll_pin_jiaoda02
  };

  public static int[] campus_icon_clicked = new int[] {
      R.drawable.ll_pin_bank, R.drawable.ll_pin_bathroom, R.drawable.ll_pin_boilingwaterroom,
      R.drawable.ll_pin_schoolgate, R.drawable.ll_pin_canteen, R.drawable.ll_pin_library,
      R.drawable.ll_pin_dorm, R.drawable.ll_pin_jianzhu01,R.drawable.ll_pin_yiyuan01,R.drawable.ll_pin_jiaoda01
  };

  public static List<BitmapDescriptor> getCampusIconList() {
    ArrayList<BitmapDescriptor> data = new ArrayList<BitmapDescriptor>();
    for (int i = 0; i < campus_icon.length; i++) {
      data.add(i, BitmapDescriptorFactory.fromResource(campus_icon[i]));
    }
    return data;
  }

  public static List<BitmapDescriptor> getCampusClickIconList() {
    ArrayList<BitmapDescriptor> data = new ArrayList<BitmapDescriptor>();
    for (int i = 0; i < campus_icon_clicked.length; i++) {
      data.add(i, BitmapDescriptorFactory.fromResource(campus_icon_clicked[i]));
    }
    return data;
  }

  //public static BitmapDescriptor getClickedIcon(int index) {
  //  if (index >= resIds.length || index < 0) {
  //    return null;
  //  }
  //  return BitmapDescriptorFactory.fromResource(resIds_clicked[index - 1]);
  //}
  //
  //public static BitmapDescriptor getIcon(int index) {
  //  if (index >= resIds.length || index < 0) {
  //    return null;
  //  }
  //  return BitmapDescriptorFactory.fromResource(resIds[index - 1]);
  //}

  public static List<BitmapDescriptor> getIconList(int size) {
    if (size > resIds.length || size < 0) {
      return null;
    }
    ArrayList<BitmapDescriptor> data = new ArrayList<BitmapDescriptor>();
    for (int i = 0; i < size; i++) {
      data.add(i, BitmapDescriptorFactory.fromResource(resIds[i]));
    }
    return data;
  }

  public static List<BitmapDescriptor> getClickedIconList(int size) {
    if (size > resIds.length || size < 0) {
      return null;
    }
    ArrayList<BitmapDescriptor> data = new ArrayList<BitmapDescriptor>();
    for (int i = 0; i < size; i++) {
      data.add(i, BitmapDescriptorFactory.fromResource(resIds_clicked[i]));
    }
    return data;
  }

  // 校验Tag Alias 只能是数字,英文字母和中文
  public static boolean isValidTagAndAlias(String s) {
    Pattern p = Pattern.compile("^[\u4E00-\u9FA50-9a-zA-Z_-]{0,}$");
    Matcher m = p.matcher(s);
    return m.matches();
  }

  public static String getImei(Context context, String imei) {
    try {
      TelephonyManager telephonyManager =
          (TelephonyManager) context.getSystemService(Context.TELEPHONY_SERVICE);
      imei = telephonyManager.getDeviceId();
    } catch (Exception e) {
      Log.e(AndroidUtils.class.getSimpleName(), e.getMessage());
    }
    return imei;
  }

  public static void showProgress(Context context) {
    if (CustomProgressDialog.customProgressDialog != null
        && !CustomProgressDialog.customProgressDialog.isShowing()) {
      CustomProgressDialog.customProgressDialog.show();
    } else if (CustomProgressDialog.customProgressDialog == null) {
      CustomProgressDialog.createDialog(context).show();
    }
  }

  public static void hideProgress() {
    if (CustomProgressDialog.customProgressDialog != null
        && CustomProgressDialog.customProgressDialog.isShowing()) {
      CustomProgressDialog.customProgressDialog.dismiss();
      CustomProgressDialog.customProgressDialog = null;
    }
  }

}
