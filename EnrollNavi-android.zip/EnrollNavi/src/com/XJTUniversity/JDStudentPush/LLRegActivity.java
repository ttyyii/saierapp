package com.XJTUniversity.JDStudentPush;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import com.XJTUniversity.JDStudentPush.model.Msg;
import com.XJTUniversity.JDStudentPush.util.Api;
import com.XJTUniversity.JDStudentPush.util.GsonRequest;
import com.XJTUniversity.JDStudentPush.util.ToastUtils;
import com.android.volley.Response;
import eu.inmite.android.lib.dialogs.ISimpleDialogListener;
import eu.inmite.android.lib.dialogs.SimpleDialogFragment;

/**
 * Created by vincent on 2014/6/24.<br/>
 * 描述: TODO
 */
public class LLRegActivity extends LLBaseActivity implements ISimpleDialogListener {

  private TextView mUname_text;
  private EditText mPwd_edit;
  private EditText mRepwd_edit;
  private ImageView mReg_btn;
  private String netId;
  private ImageView mBackBtn;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.ll_reg_activity_layout);
    netId = getIntent().getStringExtra("netid");
    bindViews();
  }

  private void bindViews() {
    TextView title = (TextView) findViewById(R.id.title_text);
    title.setVisibility(View.VISIBLE);
    title.setText("用户注册");
    mBackBtn = (ImageView) findViewById(R.id.btn_back);
    mBackBtn.setVisibility(View.VISIBLE);
    mUname_text = (TextView) findViewById(R.id.uname_text);
    mPwd_edit = (EditText) findViewById(R.id.pwd_edit);
    mRepwd_edit = (EditText) findViewById(R.id.repwd_edit);
    mReg_btn = (ImageView) findViewById(R.id.reg_btn);

    mUname_text.setText(netId);
    mReg_btn.setOnClickListener(this);
    mBackBtn.setOnClickListener(this);

    checkUserExist(netId);
  }

  private void checkUserExist(String netId) {
    String url = String.format(Api.USER_CHECK_URL, netId);
    executeRequest(new GsonRequest<Msg>(url, Msg.class, new Response.Listener<Msg>() {
      @Override public void onResponse(Msg msg) {
        if (msg != null && msg.isSuccess()) {
          SimpleDialogFragment.createBuilder(mActivity, getSupportFragmentManager())
              .setCancelableOnTouchOutside(false)
              .setMessage(msg.getMsg())
              .setRequestCode(0)
              .setNegativeButtonText(android.R.string.ok)
              .show();
        }
      }
    }, errorListener()));
  }

  @Override public void onClick(View v) {
    if (v == mReg_btn) {
      String uname = mUname_text.getText().toString();
      String pwd = mPwd_edit.getText().toString();
      String rePwd = mRepwd_edit.getText().toString();

      if (TextUtils.isEmpty(pwd)) {
        ToastUtils.show(mActivity, "密码不能为空");
        return;
      }

      if (TextUtils.isEmpty(rePwd) || !pwd.equalsIgnoreCase(rePwd)) {
        ToastUtils.show(mActivity, "两次密码输入不一致");
        return;
      }

      String url = String.format(Api.REG_URL, uname, pwd);
      executeRequest(new GsonRequest<Msg>(url, Msg.class, new Response.Listener<Msg>() {
        @Override public void onResponse(Msg msg) {
          if (msg.isSuccess()) {
            //TODO 注册成功
          }
          ToastUtils.show(mActivity, msg.getMsg());
        }
      }, errorListener()));
    } else if (v == mBackBtn) {
      finish();
    }
  }

  @Override public void onPositiveButtonClicked(int requestCode) {
    finish();
  }

  @Override public void onNegativeButtonClicked(int requestCode) {
    finish();
  }
}