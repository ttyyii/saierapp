package com.XJTUniversity.JDStudentPush;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;
import com.XJTUniversity.JDStudentPush.model.Msg;
import com.XJTUniversity.JDStudentPush.model.PushInfomation;
import com.XJTUniversity.JDStudentPush.model.PushMsg;
import com.XJTUniversity.JDStudentPush.util.AndroidUtils;
import com.XJTUniversity.JDStudentPush.util.Api;
import com.XJTUniversity.JDStudentPush.util.DateUtil;
import com.XJTUniversity.JDStudentPush.util.GsonRequest;
import com.XJTUniversity.JDStudentPush.util.PreferencesUtils;
import com.XJTUniversity.JDStudentPush.util.ToastUtils;
import com.XJTUniversity.JDStudentPush.widget.PullToRefreshBase;
import com.XJTUniversity.JDStudentPush.widget.PullToRefreshListView;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import eu.inmite.android.lib.dialogs.ISimpleDialogListener;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Set;

/**
 * Created by vincent on 2014/6/24.<br/>
 * 描述: TODO
 */
public class LLMsgActivity extends LLBaseActivity implements ISimpleDialogListener {

  private TextView mMap;

  private TextView mLogout;

  private PullToRefreshListView mListView;

  private int mCurrentPage = 0;

  private final static int mPageItemCount = 10;

  private List<PushMsg> mMsgs;
  private List<Boolean> mUnreadData;

  private MsgAdapter mAdapter;

  private JpushReceiver mReceiver;

  @Override
  protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.ll_msg_listview_layout);
    makeViews();

    // Intent locationService = new Intent(this, LLLocationService.class);
    // startService(locationService);
    mReceiver = new JpushReceiver();
    IntentFilter filter = new IntentFilter(JPushInterface.ACTION_NOTIFICATION_RECEIVED);
    filter.addCategory("com.XJTUniversity.JDStudentPush");
    registerReceiver(mReceiver, filter);
  }

  private void makeViews() {
    findViewById(R.id.title_logo).setVisibility(View.VISIBLE);
    mMap = (TextView) findViewById(R.id.map_btn);
    mLogout = (TextView) findViewById(R.id.logout_btn);
    mLogout.setVisibility(View.VISIBLE);
    mMap.setVisibility(View.VISIBLE);

    mListView = (PullToRefreshListView) findViewById(R.id.msg_listView);
    mListView.setShowIndicator(false);
    mListView.setMode(PullToRefreshBase.Mode.PULL_FROM_END);
    mListView.setOnRefreshListener(new PullToRefreshBase.OnRefreshListener<ListView>() {
      @Override
      public void onRefresh(PullToRefreshBase<ListView> refreshView) {
        App.isRefresh = true;
        sendRequest(mCurrentPage);
      }
    });

    mLogout.setOnClickListener(this);
    mMap.setOnClickListener(this);

    // 请求数据
    mMsgs = new ArrayList<PushMsg>();
    mUnreadData = new ArrayList<Boolean>();
    mAdapter = new MsgAdapter(this, mMsgs, mUnreadData);
    mListView.setAdapter(mAdapter);
    sendRequest(0);
  }

  private void sendRequest(final int pageIndex) {
    String url = String.format(Api.MSG_URL, App.NET_ID, pageIndex, mPageItemCount);
    executeRequest(new GsonRequest<PushInfomation>(url, PushInfomation.class,
        new Response.Listener<PushInfomation>() {
          @Override
          public void onResponse(PushInfomation pushInfomation) {
            App.isRefresh = false;
            if (pushInfomation != null
                && pushInfomation.getInformations() != null
                && pushInfomation.getInformations().size() > 0) {

              if (mCurrentPage == 0) {
                mMsgs.clear();
                mUnreadData.clear();
              }
              mCurrentPage++;
              mMsgs.addAll(pushInfomation.getInformations());
              if (mCurrentPage == 0) {
                for (int i = 0; i < mMsgs.size(); i++) {
                  PushMsg pushMsg = mMsgs.get(i);
                  mUnreadData.add(i, pushMsg.isRead());
                }
              } else {
                for (int i = 0; i < pushInfomation.getInformations().size(); i++) {
                  PushMsg pushMsg = pushInfomation.getInformations().get(i);
                  mUnreadData.add(pushMsg.isRead());
                }
              }

              mAdapter.notifyDataSetChanged();
            }
            if (mListView.isRefreshing()) {
              mListView.onRefreshComplete();
            }
            AndroidUtils.hideProgress();
          }
        }, new Response.ErrorListener() {
      @Override
      public void onErrorResponse(VolleyError volleyError) {
        if (mListView.isRefreshing()) {
          mListView.onRefreshComplete();
        }
        AndroidUtils.hideProgress();
      }
    }));
  }

  @Override
  public void onClick(View v) {
    if (v == mMap) {
      Intent intent = new Intent(this, LLMapActivity.class);
      startActivity(intent);
    } else if (v == mLogout) {
      // 注销
      PreferencesUtils.putBoolean(this, App.AUTO_LOGIN, false);
      PreferencesUtils.putBoolean(this, App.REM_PWD, false);
      PreferencesUtils.putBoolean(this, "hasAlias", false);
      App.NET_ID = "";
      // 注销JPUSH Alias
      setAlias("");

      Intent intent = new Intent(this, LLLoginActivity.class);
      startActivity(intent);
      finish();
    }
  }

  /**
   * 列表适配器
   */
  private class MsgAdapter extends BaseAdapter {

    private Context mContext;

    private LayoutInflater mInfater;

    private List<PushMsg> mData;

    private List<Boolean> mUnreadData;

    private MsgAdapter(Context mContext, List<PushMsg> mData, List<Boolean> mUnreadData) {
      this.mContext = mContext;
      this.mData = mData;
      this.mUnreadData = mUnreadData;
      mInfater = LayoutInflater.from(mContext);
    }

    @Override
    public int getCount() {
      return mData.size();
    }

    @Override
    public Object getItem(int position) {
      return mData.get(position);
    }

    @Override
    public long getItemId(int position) {
      return position;
    }

    @Override
    public View getView(final int position, View convertView, ViewGroup parent) {

      final ViewHolder holder;
      if (convertView == null) {
        convertView = mInfater.inflate(R.layout.ll_msg_item_layout, null);
        holder = new ViewHolder();
        holder.msg = (TextView) convertView.findViewById(R.id.msg_text);
        holder.readPoint = (ImageView) convertView.findViewById(R.id.indicator);

        //-----------start----2014-09-02
        holder.tvDate = (TextView) convertView.findViewById(R.id.tv_date);
        //-----------end----2014-09-02

        convertView.setTag(holder);
      } else {
        holder = (ViewHolder) convertView.getTag();
      }

      final PushMsg msg = mData.get(position);
      holder.msg.setText(msg.getInfoContent());
      final String type = msg.getIntoTypePid();
      int resid = 0;
      if (type.equalsIgnoreCase("1")) {
        resid = R.drawable.ll_list_01;
      } else if (type.equalsIgnoreCase("2")) {
        resid = R.drawable.ll_list_03;
      } else if (type.equalsIgnoreCase("3")) {
        resid = R.drawable.ll_list_02;
      } else if (type.equalsIgnoreCase("4")) {
        resid = R.drawable.ll_list_02;
      } else if (type.equalsIgnoreCase("5")) {
        resid = R.drawable.ll_list_02;
      }
      convertView.setBackgroundResource(resid);

      holder.readPoint.setTag(position);
      if (!mUnreadData.get(position)) {
        holder.readPoint.setVisibility(View.VISIBLE);
      } else {
        holder.readPoint.setVisibility(View.GONE);
      }

      //-----------start----2014-09-02 fix the date
      // 显示的时间
      Long time = msg.getPushDate();
      SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
      String mTime = sdf.format(new Date(time));
      holder.tvDate.setText(DateUtil.formatDateStr2Desc(mTime,DateUtil.dateFormatYMDHM));
      //-----------end----2014-09-02

      convertView.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View v) {
          messageID = msg.getInfoId();
          mUnreadData.set(position, true);
          notifyDataSetChanged();
          makeMsgReaded(messageID, msg.getInfoContent(), type);
          // LLMsgDialogFragment.show(LLMsgActivity.this,
          // msg.getInfoContent(), type);
        }
      });

      convertView.setOnLongClickListener(new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
          AlertDialog.Builder builder = new AlertDialog.Builder(mContext);
          builder.setTitle("提示");
          builder.setMessage("是否删除该消息");
          builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                  delteMsg(position, msg.getInfoId());
                }
              });

          builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialog, int which) {
                  dialog.dismiss();
                }
              });
          builder.create().show();
          return false;
        }
      });

      return convertView;
    }

    private class ViewHolder {
      TextView msg;
      ImageView readPoint;
      TextView tvDate;
    }
  }

  /**
   * 消息删除
   */
  private void delteMsg(final int position, String msgid) {
    String url = String.format(Api.DELETE_MSG_URL, msgid, App.NET_ID);
    executeRequest(new GsonRequest<Msg>(url, Msg.class, new Response.Listener<Msg>() {
      @Override
      public void onResponse(Msg msg) {
        if (msg.isSuccess()) {
          mMsgs.remove(position);
          mAdapter.notifyDataSetChanged();
          ToastUtils.show(LLMsgActivity.this, "删除成功");
        } else {
          ToastUtils.show(LLMsgActivity.this, "删除失败");
        }
        AndroidUtils.hideProgress();
      }
    }, errorListener()));
  }

  /**
   * 标记已读
   */
  private void makeMsgReaded(String infoId, final String content, final String type) {
    String url = String.format(Api.MSG_READ_URL, infoId, App.NET_ID);
    executeRequest(new GsonRequest<Msg>(url, Msg.class, new Response.Listener<Msg>() {
      @Override
      public void onResponse(Msg msg) {
        AndroidUtils.hideProgress();
        if (msg != null && msg.isSuccess()) {
          LLMsgDialogFragment.show(LLMsgActivity.this, content, type);
        }
      }
    }, errorListener()));
  }

  private String messageID;

  /**
   * dialog点击事件
   */
  @Override
  public void onPositiveButtonClicked(int requestCode) {
    Intent intent = new Intent(this, LLMapRouteActivity.class);
    intent.putExtra("type", requestCode);
    intent.putExtra("msgid", messageID);
    startActivity(intent);
  }

  @Override
  public void onNegativeButtonClicked(int requestCode) {
  }

  /** JPUSH set Alias* */
  private static final int MSG_SET_ALIAS = 1001;
  private final Handler mHandler = new Handler() {
    @Override
    public void handleMessage(android.os.Message msg) {
      super.handleMessage(msg);
      switch (msg.what) {
        case MSG_SET_ALIAS:
          // 调用 JPush 接口来设置别名。
          JPushInterface.setAliasAndTags(getApplicationContext(), (String) msg.obj, null,
              mAliasCallback);
          break;
        default:
      }
    }
  };

  private final TagAliasCallback mAliasCallback = new TagAliasCallback() {
    @Override
    public void gotResult(int code, String alias, Set<String> tags) {
      switch (code) {
        case 0:
          // 建议这里往 SharePreference 里写一个成功设置的状态。成功设置一次后，以后不必再次设置了。
          System.out.println("jpush alias set ok --->" + alias);
          PreferencesUtils.putBoolean(mActivity, "hasAlias", false);
          break;
        case 6002:
          // 延迟 60 秒来调用 Handler 设置别名
          System.out.println("jpush alias set faild --->" + alias);
          mHandler.sendMessageDelayed(mHandler.obtainMessage(MSG_SET_ALIAS, alias), 1000 * 60);
          break;
        default:
      }
    }
  };

  /**
   * set Jpush Alias
   */
  private void setAlias(String alias) {
    if (!AndroidUtils.isValidTagAndAlias(alias)) {
      Log.e(LLLoginActivity.class.getSimpleName(), "invalid jpush alias");
      return;
    }
    // 调用 Handler 来异步设置别名
    mHandler.sendMessage(mHandler.obtainMessage(MSG_SET_ALIAS, alias));
  }

  @Override
  protected void onDestroy() {
    AndroidUtils.hideProgress();
    unregisterReceiver(mReceiver);
    super.onDestroy();
  }

  @Override
  protected void onStop() {
    refreshNow = false;
    needRefresh = false;
    super.onStop();
  }

  @Override
  protected void onStart() {
    super.onStart();
    setAlias(App.NET_ID);
    refreshNow = true;
    if (mAdapter != null && needRefresh) {
      System.out.println("onStart刷新数据");
      sendRequest(0);
    }
  }

  private boolean refreshNow = true;
  private boolean needRefresh = false;

  public class JpushReceiver extends BroadcastReceiver {
    public void onReceive(Context context, Intent intent) {
      if (JPushInterface.ACTION_NOTIFICATION_RECEIVED.equals(intent.getAction())) {
        System.out.println("-----New Jpush Message Is Received----");
        if (mAdapter != null && refreshNow) {
          System.out.println("Acitvity刷新数据");
          mCurrentPage = 0;
          sendRequest(0);
        }
        needRefresh = !refreshNow;
      }
    }
  }
}