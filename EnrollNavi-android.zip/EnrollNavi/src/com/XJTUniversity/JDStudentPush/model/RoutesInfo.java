package com.XJTUniversity.JDStudentPush.model;

/**
 * Created by vincent on 2014/7/1.<br/>
 * 描述: TODO
 */
public class RoutesInfo {
  private boolean success;
  private String msg;
  private String startName;
  private String startlat;
  private String startLng;
  private String endName;
  private String endlat;
  private String endLng;
  private String reportMark;

  public String getReportMark() {
    return reportMark;
  }

  public void setReportMark(String reportMark) {
    this.reportMark = reportMark;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  public String getStartName() {
    return startName;
  }

  public void setStartName(String startName) {
    this.startName = startName;
  }

  public String getStartlat() {
    return startlat;
  }

  public void setStartlat(String startlat) {
    this.startlat = startlat;
  }

  public String getStartLng() {
    return startLng;
  }

  public void setStartLng(String startLng) {
    this.startLng = startLng;
  }

  public String getEndName() {
    return endName;
  }

  public void setEndName(String endName) {
    this.endName = endName;
  }

  public String getEndlat() {
    return endlat;
  }

  public void setEndlat(String endlat) {
    this.endlat = endlat;
  }

  public String getEndLng() {
    return endLng;
  }

  public void setEndLng(String endLng) {
    this.endLng = endLng;
  }
}
