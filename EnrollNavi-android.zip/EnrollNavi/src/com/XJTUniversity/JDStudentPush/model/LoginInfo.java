package com.XJTUniversity.JDStudentPush.model;

import org.json.JSONException;
import org.json.JSONObject;

//import org.json.JSONException;
//import org.json.JSONObject;


/**
 * 用户登录信息
 *
 */
//@SuppressWarnings("unused")
public class LoginInfo {
	
	public static final String KEY_USER_NAME = "user_name";
	public static final String KEY_USER_ENC = "user_enc";
	public static final String KEY_USER_ID = "user_id";
	public static final String KEY_USER_NO = "user_no";
	public static final String KEY_USER_TYPE = "user_type";
	public static final String KEY_USER_DEPARTMENT_ID = "user_department_id";
	public static final String KEY_USER_DEPARTMENT_NAME = "user_department_name";
	
	public LoginInfo(){}
	
	private String mUserEnc;

  private boolean success;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public void setUserEnc(String enc) {
		this.mUserEnc = enc;
	}
	
	public String getUserEnc() {
		return this.mUserEnc;
	}
	
	public void setUserNo(String no) {
		this.mUserNo = no;
	}
	
	public String getUserNo() {
		return this.mUserNo;
	}
	
	public void setUserId(String id) {
		this.mUserId = id;
	}
	
	public String getUserId() {
		return this.mUserId;//userid为userno
	}
	
	public void setUserName(String name) {
		this.mUserName = name;
	}
	
	public String getUserName() {
		return this.mUserName;
	}
	
	public int getUserType() {
		return this.mUserType;
	}
	
	public void setUserType(int type) {
		this.mUserType = type;
	}
	
	public void setDepartmentId(String id) {
		this.mDepartmentId = id;
	}
	
	public String getDepartmentId() {
		return this.mDepartmentId;
	}
	
	public static LoginInfo newInstance(String jsonStr) throws JSONException {
		LoginInfo info = new LoginInfo();
		JSONObject jsonp = new JSONObject(jsonStr);
//		JSONObject jsonp = obj.getJSONObject("jsonp");
		info.mStatus = jsonp.optInt("status");
		info.mCode = jsonp.optInt("code");
		info.mMsg = jsonp.optString("msg");
		info.mUserName = jsonp.optString("userName");
    info.success = jsonp.optBoolean("success");
		info.mDepartment = (jsonp.optString("dep"));
		info.mDepartmentId = jsonp.optString("depid");
		info.mUserNo = jsonp.optString("userno");
		info.mUserType = jsonp.optInt("usertype");
		info.mUserId = jsonp.optString("userid");
//		JSONObject data = jsonp.getJSONObject("data");
//		info.mDisplayName = data.optString("displayName");
//		info.mPhoto = data.optString("photo");
//		info.mClassInfo = data.optString("classInfo");
//		info.mTheme = data.optInt("theme");
//		info.mAdminAppIds = data.optString("adminAppIds");
//		info.mRoleId = data.optInt("roleId");
//		info.mUserType = data.optInt("usertype");
//		info.mNick = data.optString("nick");
//		info.mQQ = data.optString("qq");
//		info.mUserId = data.optString("userid");
//		info.mUserCode = data.optString("userCode");
//		info.mUserName = data.optString("username");
//		info.mPassword = data.optString("passWord");
//		info.mUserCat = data.optString("userCat");
//		info.mMobileNum = data.optString("mobileNum");
//		info.mEmail = data.optString("email");
		return info;
	}
	
	public String getDepartment() {
		return mDepartment;
	}

	public void setDepartment(String mDepartment) {
		this.mDepartment = mDepartment;
	}

	private String mUserNo;
	
	private String mDepartment;
	
	private String mDepartmentId;
	
	private String mDisplayName;
	
	private String mPhoto;
	
	private String mClassInfo;
	
	private int mTheme;
	
	private String mAdminAppIds;
	
	private int mRoleId;
	
	private int mUserType;
	
	private String mNick;
	
	private String mQQ;
	
	private String mUserId;
	
	private String mUserCode;
	
	private String mUserName;
	
	private String mPassword;
	
	private String mUserCat;
	
	private String mMobileNum;
	
	private String mEmail;
	
	private int mStatus;
	
	private int mCode;
	
	private String mMsg;
	
}
