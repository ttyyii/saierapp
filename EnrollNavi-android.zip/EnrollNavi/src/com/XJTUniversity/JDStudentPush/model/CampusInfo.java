package com.XJTUniversity.JDStudentPush.model;

import java.util.List;

/**
 * Created by vincent on 2014/7/1.<br/>
 * 描述: TODO
 */
public class CampusInfo {

  private boolean success;
  private String msg;
  private String infoId;
  private String campusName;
  private String campusLat;
  private String campusLog;
  private List<ReportMaps> reportMaps;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  public String getInfoId() {
    return infoId;
  }

  public void setInfoId(String infoId) {
    this.infoId = infoId;
  }

  public String getCampusName() {
    return campusName;
  }

  public void setCampusName(String campusName) {
    this.campusName = campusName;
  }

  public String getCampusLat() {
    return campusLat;
  }

  public void setCampusLat(String campusLat) {
    this.campusLat = campusLat;
  }

  public String getCampusLog() {
    return campusLog;
  }

  public void setCampusLog(String campusLog) {
    this.campusLog = campusLog;
  }

  public List<ReportMaps> getReportMaps() {
    return reportMaps;
  }

  public void setReportMaps(List<ReportMaps> reportMaps) {
    this.reportMaps = reportMaps;
  }
}
