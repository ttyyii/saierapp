package com.XJTUniversity.JDStudentPush.model;

import java.io.Serializable;

/**
 * Created by vincent on 2014/6/25.<br/>
 * 描述: TODO
 */
public class PushMsg implements Serializable {

  private boolean success;
  private String msg;
  private String infoId;
  private String intoTypePid;
  private String infoContent;
  private long pushDate;
  private boolean isRead;

  public boolean isRead() {
    return isRead;
  }

  public void setRead(boolean isRead) {
    this.isRead = isRead;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  public String getInfoId() {
    return infoId;
  }

  public void setInfoId(String infoId) {
    this.infoId = infoId;
  }

  public String getIntoTypePid() {
    return intoTypePid;
  }

  public void setIntoTypePid(String intoTypePid) {
    this.intoTypePid = intoTypePid;
  }

  public String getInfoContent() {
    return infoContent;
  }

  public void setInfoContent(String infoContent) {
    this.infoContent = infoContent;
  }

  public long getPushDate() {
    return pushDate;
  }

  public void setPushDate(long pushDate) {
    this.pushDate = pushDate;
  }
}
