package com.XJTUniversity.JDStudentPush.model;

/**
 * Created by vincent on 2014/7/2.<br/>
 * 描述: TODO
 */
public class ReportMaps {
  private String reportMapId;
  private String reportMapTitle;
  private String reportMapLat;
  private String reportMapLng;
  private String reportMapPic;
  private String reportMapDesc;
  private long reportMapTime;
  private int reportMapIndex;

  public String getReportMapId() {
    return reportMapId;
  }

  public void setReportMapId(String reportMapId) {
    this.reportMapId = reportMapId;
  }

  public String getReportMapTitle() {
    return reportMapTitle;
  }

  public void setReportMapTitle(String reportMapTitle) {
    this.reportMapTitle = reportMapTitle;
  }

  public String getReportMapLat() {
    return reportMapLat;
  }

  public void setReportMapLat(String reportMapLat) {
    this.reportMapLat = reportMapLat;
  }

  public String getReportMapLng() {
    return reportMapLng;
  }

  public void setReportMapLng(String reportMapLng) {
    this.reportMapLng = reportMapLng;
  }

  public String getReportMapPic() {
    return reportMapPic;
  }

  public void setReportMapPic(String reportMapPic) {
    this.reportMapPic = reportMapPic;
  }

  public String getReportMapDesc() {
    return reportMapDesc;
  }

  public void setReportMapDesc(String reportMapDesc) {
    this.reportMapDesc = reportMapDesc;
  }

  public long getReportMapTime() {
    return reportMapTime;
  }

  public void setReportMapTime(long reportMapTime) {
    this.reportMapTime = reportMapTime;
  }

  public int getReportMapIndex() {
    return reportMapIndex;
  }

  public void setReportMapIndex(int reportMapIndex) {
    this.reportMapIndex = reportMapIndex;
  }
}
