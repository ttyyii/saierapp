package com.XJTUniversity.JDStudentPush.model;

import java.util.List;

/**
 * Created by vincent on 2014/6/30.<br/>
 * 描述: TODO
 */
public class CampusMap {

  private int count;
  private List<CampusMapPoints> campusMaps;

  public int getCount() {
    return count;
  }

  public void setCount(int count) {
    this.count = count;
  }

  public List<CampusMapPoints> getCampusMaps() {
    return campusMaps;
  }

  public void setCampusMaps(List<CampusMapPoints> campusMaps) {
    this.campusMaps = campusMaps;
  }
}
