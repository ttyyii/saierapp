package com.XJTUniversity.JDStudentPush.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by vincent on 2014/6/25.<br/>
 * 描述: TODO
 */
public class PushInfomation implements Serializable {
  private List<PushMsg> informations;
  private int count;
  private boolean success;
  private String msg;

  public List<PushMsg> getInformations() {
    return informations;
  }

  public void setInformations(List<PushMsg> informations) {
    this.informations = informations;
  }

  public int getCount() {
    return count;
  }

  public void setCount(int count) {
    this.count = count;
  }

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }
}
