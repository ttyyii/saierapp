package com.XJTUniversity.JDStudentPush.model;

import org.json.JSONException;
import org.json.JSONObject;

/**
 * 用户登录信息
 */
public class User {

  public static final String KEY_USER_NAME = "user_name";
  public static final String KEY_USER_ID = "user_id";

  public User() {
  }

  // private String mUserEnc;
  //
  // public void setUserEnc(String enc) {
  // this.mUserEnc = enc;
  // }
  //
  // public String getUserEnc() {
  // return this.mUserEnc;
  // }

  public void setUserId(String id) {
    this.mUserId = id;
  }

  public String getUserId() {
    return this.mUserId;
  }

  public void setUserName(String name) {
    this.mUserName = name;
  }

  public String getUserName() {
    return this.mUserName;
  }

  public static User newInstance(String jsonStr) throws JSONException {
    User info = new User();
    JSONObject obj = new JSONObject(jsonStr);
    info.mTel = obj.optString("tel");
    info.mUserName = obj.optString("name");
    info.mEmail = obj.optString("email");
    info.mPhoto = obj.optString("img");
    info.mBirthday = obj.optString("birthday");
    info.mDepartment = obj.optString("department");
    return info;
  }

  public String getmDepartment() {
    if (mDepartment == null) {
      mDepartment = "";
    }
    return mDepartment;
  }

  public void setmDepartment(String mDepartment) {
    this.mDepartment = mDepartment;
  }

  public String getmUserId() {
    return mUserId;
  }

  public void setmUserId(String mUserId) {
    this.mUserId = mUserId;
  }

  public String getmUserName() {
    if (mUserName == null) {
      mUserName = "";
    }
    return mUserName;
  }

  public void setmUserName(String mUserName) {
    this.mUserName = mUserName;
  }

  public String getmTel() {
    if (mTel == null) {
      mTel = "";
    }
    return mTel;
  }

  public void setmTel(String mTel) {
    this.mTel = mTel;
  }

  public String getmEmail() {
    if (mEmail == null) {
      mEmail = "";
    }
    return mEmail;
  }

  public void setmEmail(String mEmail) {
    this.mEmail = mEmail;
  }

  public String getmPhoto() {
    if (mPhoto == null) {
      mPhoto = "";
    }
    return mPhoto;
  }

  public void setmPhoto(String mPhoto) {
    this.mPhoto = mPhoto;
  }

  public String getmBirthday() {
    if (mBirthday == null) {
      mBirthday = "";
    }
    return mBirthday;
  }

  public void setmBirthday(String mBirthday) {
    this.mBirthday = mBirthday;
  }

  private String mDepartment;

  private String mUserId;

  private String mUserName;

  private String mTel;

  private String mEmail;

  private String mPhoto;

  private String mBirthday;
}
