package com.XJTUniversity.JDStudentPush.model;

import java.io.Serializable;
import java.util.List;

/**
 * Created by vincent on 2014/6/25.<br/>
 * 描述: TODO
 */
public class ReadMark implements Serializable {
  public List<String> ids;
}
