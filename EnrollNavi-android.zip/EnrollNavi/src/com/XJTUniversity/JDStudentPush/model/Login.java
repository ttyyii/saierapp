package com.XJTUniversity.JDStudentPush.model;

/**
 * Created by vincent on 2014/6/23.<br/>
 * 描述: TODO
 */
public class Login {
  private boolean success;
  private String msg;
  private String userId;

  public boolean isSuccess() {
    return success;
  }

  public void setSuccess(boolean success) {
    this.success = success;
  }

  public String getMsg() {
    return msg;
  }

  public void setMsg(String msg) {
    this.msg = msg;
  }

  public String getUserId() {
    return userId;
  }

  public void setUserId(String userId) {
    this.userId = userId;
  }
}
