package com.XJTUniversity.JDStudentPush.model;

/**
 * Created by vincent on 2014/6/30.<br/>
 * 描述: TODO
 */
public class CampusMapPoints {

  private String campusMapId;
  private String campusMapTitle;
  private String campusMapLog;
  private String campusMapLat;
  private String campusMapPic;
  private String campusMapDescription;
  private String campusMapIndex;
  private String mapTypeId;

  public String getCampusMapId() {
    return campusMapId;
  }

  public void setCampusMapId(String campusMapId) {
    this.campusMapId = campusMapId;
  }

  public String getCampusMapTitle() {
    return campusMapTitle;
  }

  public void setCampusMapTitle(String campusMapTitle) {
    this.campusMapTitle = campusMapTitle;
  }

  public String getCampusMapLog() {
    return campusMapLog;
  }

  public void setCampusMapLog(String campusMapLog) {
    this.campusMapLog = campusMapLog;
  }

  public String getCampusMapLat() {
    return campusMapLat;
  }

  public void setCampusMapLat(String campusMapLat) {
    this.campusMapLat = campusMapLat;
  }

  public String getCampusMapPic() {
    return campusMapPic;
  }

  public void setCampusMapPic(String campusMapPic) {
    this.campusMapPic = campusMapPic;
  }

  public String getCampusMapDescription() {
    return campusMapDescription;
  }

  public void setCampusMapDescription(String campusMapDescription) {
    this.campusMapDescription = campusMapDescription;
  }

  public String getCampusMapIndex() {
    return campusMapIndex;
  }

  public void setCampusMapIndex(String campusMapIndex) {
    this.campusMapIndex = campusMapIndex;
  }

  public String getMapTypeId() {
    return mapTypeId;
  }

  public void setMapTypeId(String mapTypeId) {
    this.mapTypeId = mapTypeId;
  }
}
