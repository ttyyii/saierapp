package com.XJTUniversity.JDStudentPush;

import android.app.Service;
import android.content.Intent;
import android.os.Binder;
import android.os.IBinder;
import android.text.TextUtils;
import com.XJTUniversity.JDStudentPush.model.Msg;
import com.XJTUniversity.JDStudentPush.util.Api;
import com.XJTUniversity.JDStudentPush.util.GsonRequest;
import com.XJTUniversity.JDStudentPush.util.Point;
import com.XJTUniversity.JDStudentPush.util.Polygon;
import com.XJTUniversity.JDStudentPush.util.PreferencesUtils;
import com.XJTUniversity.JDStudentPush.util.RequestManager;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;

/**
 * Created by vincent on 2014/6/26.<br/>
 * 描述: TODO
 */
public class LLLocationService extends Service {

  private LocationClient mLocationClient;

  private BDLocation mCurrentLocation;

  private LocationBinder mBinder = new LocationBinder();

  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mYTMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mQJMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mTrainMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXNTrainMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mFLYMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();
  //private HashMap<Integer,Boolean> mXQMap = new HashMap<Integer, Boolean>();

  private final static int IN_XQ = 2001;
  private final static int IN_YT = 2002;
  private final static int IN_QJ = 2003;
  private final static int IN_TRAIN = 1001;
  private final static int IN_NTRAIN = 1002;
  private final static int IN_FLY = 1003;
  private final static int IN_CN = 1004;
  private final static int IN_CX = 1005;
  private final static int IN_TBUS = 1006;
  private final static int IN_CB = 1007;
  private final static int IN_SFW = 1008;

  private Polygon mXQPolygon;
  private Polygon mYTPolygon;
  private Polygon mQJPolygon;
  private Polygon mTrainPolygon;
  private Polygon mTrainNorthPolygon;
  private Polygon mFlyPolygon;
  private Polygon mCNPolygon;
  private Polygon mCXPolygon;
  private Polygon mTBUSPolygon;
  private Polygon mCBPolygon;
  private Polygon mSFWPolygon;

  @Override public IBinder onBind(Intent intent) {
    if (mLocationClient != null && !mLocationClient.isStarted()) {
      mLocationClient.start();
    }
    return mBinder;
  }

  @Override public boolean onUnbind(Intent intent) {
    if (mLocationClient != null && mLocationClient.isStarted()) {
      mLocationClient.stop();
    }
    return super.onUnbind(intent);
  }

  @Override public void onCreate() {
    super.onCreate();
    initLocationClient();
    initAllRegion();
  }

  private void initAllRegion() {
    //兴庆校区
    Polygon.Builder builder = Polygon.Builder();
    builder.addVertex(new Point(108.983542f, 34.258543f));
    builder.addVertex(new Point(108.997501f, 34.25905f));
    builder.addVertex(new Point(108.997214f, 34.246578f));
    builder.addVertex(new Point(108.982374f, 34.245354f));
    mXQPolygon = builder.build();

    //雁塔校区
    Polygon.Builder builder1 = Polygon.Builder();
    builder1.addVertex(new Point(108.940288f, 34.224403f));
    builder1.addVertex(new Point(108.952972f, 34.224403f));
    builder1.addVertex(new Point(108.952972f, 34.220224f));
    builder1.addVertex(new Point(108.940288f, 34.220224f));
    mYTPolygon = builder1.build();

    //曲江校区
    Polygon.Builder builder2 = Polygon.Builder();
    builder2.addVertex(new Point(109.004158f, 34.230171f));
    builder2.addVertex(new Point(109.008721f, 34.23229f));
    builder2.addVertex(new Point(109.011506f, 34.228037f));
    builder2.addVertex(new Point(109.006727f, 34.226022f));
    mQJPolygon = builder2.build();

    //火车站
    Polygon.Builder builder3 = Polygon.Builder();
    builder3.addVertex(new Point(108.965926f, 34.285115f));
    builder3.addVertex(new Point(108.971684f, 34.285115f));
    builder3.addVertex(new Point(108.971684f, 34.281715f));
    builder3.addVertex(new Point(108.965926f, 34.281715f));
    mTrainPolygon = builder3.build();

    //火车站北
    Polygon.Builder builder4 = Polygon.Builder();
    builder4.addVertex(new Point(108.940073f, 34.384127f));
    builder4.addVertex(new Point(108.948157f, 34.386242f));
    builder4.addVertex(new Point(108.95211f, 34.377721f));
    builder4.addVertex(new Point(108.942516f, 34.375308f));
    mTrainNorthPolygon = builder4.build();

    //咸阳机场
    Polygon.Builder builder5 = Polygon.Builder();
    builder5.addVertex(new Point(108.738349f, 34.442319f));
    builder5.addVertex(new Point(108.78463f, 34.469941f));
    builder5.addVertex(new Point(108.803602f, 34.447082f));
    builder5.addVertex(new Point(108.758902f, 34.419749f));
    mFlyPolygon = builder5.build();

    //城南客运站
    Polygon.Builder builder6 = Polygon.Builder();
    builder6.addVertex(new Point(108.941405f, 34.193101f));
    builder6.addVertex(new Point(108.94613f, 34.193101f));
    builder6.addVertex(new Point(108.941944f, 34.188353f));
    builder6.addVertex(new Point(108.946633f, 34.188592f));
    mCNPolygon = builder6.build();

    //城西客运站
    Polygon.Builder builder7 = Polygon.Builder();
    builder7.addVertex(new Point(108.877855f, 34.283421f));
    builder7.addVertex(new Point(108.884592f, 34.283317f));
    builder7.addVertex(new Point(108.882571f, 34.278529f));
    builder7.addVertex(new Point(108.877729f, 34.278305f));
    mCXPolygon = builder7.build();

    //火车站汽车站
    Polygon.Builder builder8 = Polygon.Builder();
    builder8.addVertex(new Point(108.966683f, 34.282306f));
    builder8.addVertex(new Point(108.969208f, 34.281781f));
    builder8.addVertex(new Point(108.968812f, 34.281095f));
    builder8.addVertex(new Point(108.966261f, 34.281139f));
    mTBUSPolygon = builder8.build();

    //城北客运站
    Polygon.Builder builder9 = Polygon.Builder();
    builder9.addVertex(new Point(108.944289f, 34.317999f));
    builder9.addVertex(new Point(108.949085f, 34.318044f));
    builder9.addVertex(new Point(108.948888f, 34.315688f));
    builder9.addVertex(new Point(108.943911f, 34.314869f));
    mCBPolygon = builder9.build();

    //三府湾
    Polygon.Builder builder10 = Polygon.Builder();
    builder10.addVertex(new Point(108.981906f, 34.28435f));
    builder10.addVertex(new Point(108.984745f, 34.284529f));
    builder10.addVertex(new Point(108.984224f, 34.283015f));
    builder10.addVertex(new Point(108.982553f, 34.283179f));
    mSFWPolygon = builder10.build();
  }

  private int getInsideRegion() {
    if (mCurrentLocation == null) {
      return -1;
    }

    if (mXQPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_XQ;
    }

    if (mYTPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_YT;
    }

    if (mQJPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_QJ;
    }

    if (mTrainPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_TRAIN;
    }

    if (mTrainNorthPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_NTRAIN;
    }

    if (mFlyPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_FLY;
    }

    if (mCNPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_CN;
    }

    if (mCXPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_CX;
    }

    if (mTBUSPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_TBUS;
    }

    if (mCBPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_CB;
    }

    if (mSFWPolygon.contains(new Point((float) mCurrentLocation.getLongitude(),
        (float) mCurrentLocation.getLatitude()))) {
      return IN_SFW;
    }

    return -1;
  }

  public BDLocation getmCurrentLocation() {
    return mCurrentLocation;
  }

  private void initLocationClient() {
    mLocationClient = new LocationClient(this);
    LocationClientOption option = new LocationClientOption();
    option.setOpenGps(true);
    option.setCoorType("bd09ll");
    option.setScanSpan(3000);
    mLocationClient.setLocOption(option);
    mLocationClient.registerLocationListener(new MyLocationListener());
    mLocationClient.start();
  }

  int flag = 0;

  private class MyLocationListener implements BDLocationListener {
    @Override public void onReceiveLocation(BDLocation bdLocation) {
      flag = flag + 3;
      if (bdLocation == null) {
        return;
      }
      mCurrentLocation = bdLocation;
      boolean hasAlias = PreferencesUtils.getBoolean(LLLocationService.this, "hasAlias");
      if (!hasAlias) return;

      int kindCode = getInsideRegion();
      if (flag == 30 && kindCode != -1) {
        flag = 0;
        //boolean isPushed = PreferencesUtils.getBoolean(LocationService.this,kindCode+"",false);
        //if (!isPushed) {
        System.out.println("The current region code is:----> " + kindCode);
        sendRequest(kindCode);
        //}
      }

      //switch (getInsideRegion()) {
      //  case IN_XQ:
      //    //ToastUtils.show(LocationService.this,"in XQ");
      //    break;
      //  case IN_YT:
      //    //ToastUtils.show(LocationService.this,"in YT");
      //    break;
      //  case IN_QJ:
      //    break;
      //  case IN_TRAIN:
      //    break;
      //  case IN_NTRAIN:
      //    break;
      //  case IN_FLY:
      //    break;
      //  case IN_CN:
      //    break;
      //  case IN_CX:
      //    break;
      //  case IN_TBUS:
      //    break;
      //  case IN_CB:
      //    break;
      //  case IN_SFW:
      //    break;
      //  default:
      //    break;
      //}
    }

    //@Override public void onReceivePoi(BDLocation bdLocation) {
    //
    //}
  }

  /**
   * 请求对应消息推送
   */
  private void sendRequest(final int kindCode) {
    final String uname = PreferencesUtils.getString(this, App.UNAME);
    if (TextUtils.isEmpty(uname)) {
      return;
    }

    int value = PreferencesUtils.getInt(this, kindCode + uname, -1);
    if (value == kindCode) {
      return;
    }

    String url;
    if (kindCode == IN_YT || kindCode == IN_QJ || kindCode == IN_XQ) {
      url = String.format(Api.IN_CAMPUS_MSG_URL, uname);
    } else {
      url = String.format(Api.MSG_PUSH_URL, uname, kindCode);
    }
    GsonRequest<Msg> gsonRequest =
        new GsonRequest<Msg>(url, Msg.class, new Response.Listener<Msg>() {
          @Override public void onResponse(Msg msg) {
            if (msg.isSuccess()) {
              //PreferencesUtils.putBoolean(LocationService.this,kindCode+"",true);
              PreferencesUtils.putInt(LLLocationService.this, kindCode + uname, kindCode);
            }
          }
        }, new Response.ErrorListener() {
          @Override public void onErrorResponse(VolleyError volleyError) {
            //TODO request error handle
          }
        });
    RequestManager.addRequest(gsonRequest, this);
  }

  public final class LocationBinder extends Binder {
    public LLLocationService getService() {
      return LLLocationService.this;
    }
  }

  @Override public void onDestroy() {
    if (mLocationClient != null) {
      mLocationClient.stop();
    }
    super.onDestroy();
  }
}
