package com.XJTUniversity.JDStudentPush;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.http.SslError;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.webkit.CookieManager;
import android.webkit.JavascriptInterface;
import android.webkit.SslErrorHandler;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.TextView;
import com.XJTUniversity.JDStudentPush.model.LoginInfo;
import com.XJTUniversity.JDStudentPush.util.AndroidUtils;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LLAuthActivity extends FragmentActivity {

  private static final int LOGOUT_SUCCESS = 1;

  private static final int LOGOUT_FAILED = 2;

  private static final int HIDE_WEBVIEW = 3;

  private static final int SHOW_WEBVIEW = 4;

  private static final int FINISH = 5;

  private String to;

  private WebView mWeb;

  private String netID;

  private boolean isCancel = false;

  private Handler mHandler = new Handler() {
    @Override public void handleMessage(Message msg) {
      switch (msg.what) {
        case HIDE_WEBVIEW:
          AndroidUtils.showProgress(LLAuthActivity.this);
          mWeb.setVisibility(View.INVISIBLE);
          break;
        case SHOW_WEBVIEW:
          mWeb.setVisibility(View.VISIBLE);
          AndroidUtils.hideProgress();
          break;
        case FINISH:
          AndroidUtils.hideProgress();
          if (isCancel) {
            return;
          }
          if (!TextUtils.isEmpty(netID)) {
            Intent intent = null;
            if (to.equalsIgnoreCase("toreg")) {
              intent = new Intent(LLAuthActivity.this, LLRegActivity.class);
            } else if (to.equalsIgnoreCase("topwd")) {
              intent = new Intent(LLAuthActivity.this, LLPwdActivity.class);
            }
            if (intent != null) {
              intent.putExtra("netid", netID);
              startActivity(intent);
            }
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookie();
            finish();
          }
          break;
      }
    }
  };

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    setContentView(R.layout.ll_auth_activity_layout);
    to = getIntent().getStringExtra("to");

    TextView backBtn = (TextView) findViewById(R.id.logout_btn);
    backBtn.setVisibility(View.VISIBLE);
    backBtn.setText(getString(R.string.cancel));
    TextView title = (TextView) findViewById(R.id.title_text);
    title.setVisibility(View.VISIBLE);
    title.setText(getString(R.string.auth));
    backBtn.setOnClickListener(new View.OnClickListener() {
      @Override public void onClick(View v) {
        isCancel = true;
        finish();
      }
    });

    mWeb = (WebView) findViewById(R.id.reg_web);
    mWeb.getSettings().setJavaScriptEnabled(true);
    mWeb.getSettings().setSaveFormData(false);
    mWeb.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NORMAL);
    String userAgent = mWeb.getSettings().getUserAgentString();
    if (userAgent.contains("Chrome/")) {
      Pattern pattern = Pattern.compile("(Chrome/[0-9\\.]* )+?");
      Matcher matcher = pattern.matcher(userAgent);
      if (matcher.find()) {
        userAgent = userAgent.replaceAll("(Chrome/[0-9\\.]* )+?", "");
      }
    }
    mWeb.getSettings().setUserAgentString(userAgent);
    mWeb.addJavascriptInterface(new HtmlContent(), "HtmlContent");
    mWeb.setWebViewClient(new WebViewClient() {
      @Override public boolean shouldOverrideUrlLoading(WebView view, String url) {
        view.loadUrl(url);
        return true;
      }

      @Override public void onPageFinished(WebView view, String url) {
        super.onPageFinished(view, url);
        mWeb.loadUrl(
            "javascript:window.HtmlContent.getContent(document.documentElement.innerHTML)");
        mHandler.sendEmptyMessageDelayed(SHOW_WEBVIEW, 2000L);
      }

      @Override public void onReceivedSslError(WebView view, SslErrorHandler handler,
          SslError error) {
        handler.proceed();
      }

      @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
        super.onPageStarted(view, url, favicon);
        mHandler.removeMessages(SHOW_WEBVIEW);
        mHandler.sendEmptyMessage(HIDE_WEBVIEW);
      }
    });
    CookieManager cm = CookieManager.getInstance();
    cm.removeAllCookie();
    mWeb.loadUrl("http://202.117.1.206:8099/SchoolReportGuide/cas/caslogin.jsp");
  }

  class HtmlContent {
    @JavascriptInterface
    public void getContent(String content) {
      if (content.contains("userName")) {
        Pattern p = Pattern.compile("<body>(\\{.*?\\})</body>");
        Matcher m = p.matcher(content);
        while (m.find()) {
          mHandler.sendEmptyMessage(HIDE_WEBVIEW);
          String jsonStr = m.group(1);
          LoginInfo info = null;
          try {
            info = LoginInfo.newInstance(jsonStr);
          } catch (Exception e) {
            e.printStackTrace();
          }
          if (info != null) {
            netID = info.getUserName();
            //ToastUtils.show(AuthActivity.this, "统一身份认证成功");
          } else {
            netID = "";
            CookieManager cm = CookieManager.getInstance();
            cm.removeAllCookie();
            //ToastUtils.show(AuthActivity.this, "统一身份认证失败");
          }
          mHandler.sendEmptyMessage(FINISH);
        }
      }
    }
  }
}
