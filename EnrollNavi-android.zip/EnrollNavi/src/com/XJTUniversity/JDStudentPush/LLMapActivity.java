package com.XJTUniversity.JDStudentPush;

import android.content.ComponentName;
import android.content.Context;
import android.content.ServiceConnection;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.os.IBinder;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import com.XJTUniversity.JDStudentPush.model.CampusMap;
import com.XJTUniversity.JDStudentPush.model.CampusMapPoints;
import com.XJTUniversity.JDStudentPush.util.AndroidUtils;
import com.XJTUniversity.JDStudentPush.util.Api;
import com.XJTUniversity.JDStudentPush.util.DipPxUtils;
import com.XJTUniversity.JDStudentPush.util.GsonRequest;
import com.XJTUniversity.JDStudentPush.util.ToastUtils;
import com.android.volley.Response;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.overlayutil.WalkingRouteOverlay;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.route.DrivingRouteResult;
import com.baidu.mapapi.search.route.OnGetRoutePlanResultListener;
import com.baidu.mapapi.search.route.PlanNode;
import com.baidu.mapapi.search.route.RoutePlanSearch;
import com.baidu.mapapi.search.route.TransitRouteResult;
import com.baidu.mapapi.search.route.WalkingRoutePlanOption;
import com.baidu.mapapi.search.route.WalkingRouteResult;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;

/**
 * Created by vincent on 2014/6/19.<br/>
 * 描述: TODO
 */
public class LLMapActivity extends LLBaseActivity implements BaiduMap.OnMapClickListener, SensorEventListener,
		BaiduMap.OnMarkerClickListener, OnGetRoutePlanResultListener {

	private MapView mMapView;

	private BaiduMap mBaidumap;

	private LocationClient mLocationClient;

	private boolean isFirstLoc = true;

	private DescriptionPopupWindow mPopupWindow;

	private int mPopupYOffset;

	private BDLocation mCurrentLocation;

	private boolean isRunning = true;

	private Handler mHandler = new Handler();

	private RoutePlanSearch mRouteSearch;

	private RadioGroup mXiaoQuGroup;

	private RadioButton mXQ;

	private RadioButton mYT;

	private ImageView mBackBtn;

	// FIXME NO USE
	private ServiceConnection mConnection = new ServiceConnection() {
		@Override
		public void onServiceConnected(ComponentName name, final IBinder service) {
			final LLLocationService locationService = ((LLLocationService.LocationBinder) service).getService();
			if (locationService.getmCurrentLocation() != null) {
				ScheduledExecutorService timer = Executors.newSingleThreadScheduledExecutor();
				timer.scheduleAtFixedRate(new Runnable() {
					@Override
					public void run() {
						if (isRunning) {
							mCurrentLocation = locationService.getmCurrentLocation();
							if (mBaidumap != null) {
								mHandler.postDelayed(new Runnable() {
									@Override
									public void run() {
										if (!isAdded) {
											addSelfOverlay(new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation
													.getLongitude()));
										}
									}
								}, 500L);

								// 第一次获取到位置后移动到该位置
								if (isFirstLoc) {
									isFirstLoc = false;
									LatLng ll = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation
											.getLongitude());
									MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(ll);
									mBaidumap.animateMapStatus(u);
								}
							}
						}
					}
				}, 0, 1, TimeUnit.SECONDS);
			}
		}

		@Override
		public void onServiceDisconnected(ComponentName name) {
			isRunning = false;
		}
	};

	@Override
	protected void onStart() {
		// Intent intent = new Intent(this, LocationService.class);
		// bindService(intent, mConnection, BIND_AUTO_CREATE);
		super.onStart();
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ll_map_layout);

		mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		mAccelerometer = mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		mMagnetometer = mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);

		mPopupWindow = new DescriptionPopupWindow(this);
		mPopupWindow.setBackgroundDrawable(null);
		mPopupYOffset = getResources().getDrawable(R.drawable.ll_view_pop).getIntrinsicHeight();

		mRouteSearch = RoutePlanSearch.newInstance();
		mRouteSearch.setOnGetRoutePlanResultListener(this);

		findViewById(R.id.title_layout).setVisibility(View.VISIBLE);
		mBackBtn = (ImageView) findViewById(R.id.back_btn);
		mBackBtn.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				finish();
			}
		});
		mXiaoQuGroup = (RadioGroup) findViewById(R.id.option_group);
		mXQ = (RadioButton) findViewById(R.id.xq_rb);
		mYT = (RadioButton) findViewById(R.id.yt_rb);
		mXiaoQuGroup.check(R.id.xq_rb);
		mXQ.setTextColor(getResources().getColor(android.R.color.black));
		mYT.setTextColor(getResources().getColor(android.R.color.white));
		mXQ.setText("兴庆校区");
		mYT.setText("雁塔校区");
		mXiaoQuGroup.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(RadioGroup group, int checkedId) {
				if (mXQ.isChecked()) {
					mXQ.setTextColor(getResources().getColor(android.R.color.black));
					mYT.setTextColor(getResources().getColor(android.R.color.white));
					mBaidumap.setMapStatus(MapStatusUpdateFactory.newLatLng(new LatLng(34.252859, 108.990144)));
				} else if (mYT.isChecked()) {
					mXQ.setTextColor(getResources().getColor(android.R.color.white));
					mYT.setTextColor(getResources().getColor(android.R.color.black));
					mBaidumap.setMapStatus(MapStatusUpdateFactory.newLatLng(new LatLng(34.222717, 108.948786)));
				}
			}
		});
		initMap();
	}

	/**
	 * 初始化地图
	 */

	// 校园地图自身位置扎点图标
	private void initMap() {
		mMapView = (MapView) findViewById(R.id.bd_mapview);
		mBaidumap = mMapView.getMap();
		mBaidumap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
		// mBaidumap.setTrafficEnabled(true);
		// mBaidumap.setMyLocationEnabled(true);
		mBaidumap.setOnMapClickListener(this);
		mBaidumap.setMapStatus(MapStatusUpdateFactory.zoomTo(17.0f));
		mBaidumap.setMapStatus(MapStatusUpdateFactory.newLatLng(new LatLng(34.252859, 108.990144)));
		// marker点击事件
		mBaidumap.setOnMarkerClickListener(this);
		mBaidumap.setOnMapLoadedCallback(new BaiduMap.OnMapLoadedCallback() {
			@Override
			public void onMapLoaded() {
				getMyPositionOnMap();
				getCampusPoint();
			}
		});
	}

	/**
	 * 定位
	 */
	private void getMyPositionOnMap() {
		mLocationClient = ((App) getApplication()).mBDLocationClient;
		mLocationClient.registerLocationListener(new MyBDLocationListener());
		LocationClientOption option = new LocationClientOption();
		option.setOpenGps(true);
		option.setCoorType("bd09ll");
		option.setScanSpan(1000);
		option.setNeedDeviceDirect(true);
		mLocationClient.setLocOption(option);
		if (mLocationClient != null && !mLocationClient.isStarted()) {
			mLocationClient.start();
		}
	}

	/**
	 * 请求校园点数据
	 */
	private void getCampusPoint() {
		String url = String.format(Api.CAMPUS_MAP_URL, "-1");
		executeRequest(new GsonRequest<CampusMap>(url, CampusMap.class, new Response.Listener<CampusMap>() {
			@Override
			public void onResponse(CampusMap campusMap) {
				AndroidUtils.hideProgress();
				if (campusMap != null && campusMap.getCampusMaps() != null) {
					initOverlay(campusMap.getCampusMaps());
				}
			}
		}, errorListener()));
	}

	/**
	 * 初始化扎点
	 */
	private List<BitmapDescriptor> icons;
	private List<BitmapDescriptor> clicked_icons;
	private List<Overlay> allOverLays;

	private void initOverlay(List<CampusMapPoints> points) {
		if (points == null || points.size() <= 0) {
			return;
		}
		allOverLays = new ArrayList<Overlay>();
		icons = new ArrayList<BitmapDescriptor>();
		clicked_icons = new ArrayList<BitmapDescriptor>();
		icons.addAll(AndroidUtils.getCampusIconList());
		clicked_icons.addAll(AndroidUtils.getCampusClickIconList());
		mBaidumap.clear();
		for (CampusMapPoints p : points) {
			if (TextUtils.isEmpty(p.getCampusMapLat()) || TextUtils.isEmpty(p.getCampusMapLog())) {
				continue;
			}

			double lat = Double.parseDouble(p.getCampusMapLat());
			double lon = Double.parseDouble(p.getCampusMapLog());
			LatLng pos = new LatLng(lat, lon);
			Bundle b = new Bundle();
			b.putString("title", p.getCampusMapTitle());
			b.putString("desc", p.getCampusMapDescription());
			b.putString("url", p.getCampusMapPic());

			BitmapDescriptor icon = null;
			if (!TextUtils.isEmpty(p.getMapTypeId())) {
				int type = Integer.parseInt(p.getMapTypeId());
				if (type > icons.size() - 1) {
					icon = icons.get(icons.size() - 1);
				} else {
					icon = icons.get(type - 1);
				}
				b.putInt("type", type);
			}

			OverlayOptions oo = new MarkerOptions().position(pos).icon(icon).extraInfo(b);
			Overlay overlay = mBaidumap.addOverlay(oo);
			allOverLays.add(overlay);
		}
	}

	/**
	 * 自身扎点
	 */
	private BitmapDescriptor selfIcon = BitmapDescriptorFactory.fromResource(R.drawable.ll_mylocation);
	private Overlay selfOverlay;
	private boolean isAdded = false;

	private void addSelfOverlay(final LatLng latLng) {
		if (selfIcon == null) {
			selfIcon = BitmapDescriptorFactory.fromResource(R.drawable.ll_mylocation);
		}
		final OverlayOptions oo = new MarkerOptions().position(latLng).icon(selfIcon).anchor(0.5f, 0.5f);
		try {
			selfOverlay = mBaidumap.addOverlay(oo);
		} catch (Exception e) {
			System.err.println(e.toString());
		}
		isAdded = true;
	}

	/**
	 * 扎点点击事件
	 */
	private LatLng mDestinationPoint;

	@Override
	public boolean onMarkerClick(Marker marker) {
		if (marker.getExtraInfo() == null) {
			return true;
		}
		mDestinationPoint = marker.getPosition();
		String title = marker.getExtraInfo().getString("title");
		String desc = marker.getExtraInfo().getString("desc");
		String url = marker.getExtraInfo().getString("url");
		int index = marker.getExtraInfo().getInt("type", -1);

		// 清除marker状态
		for (Overlay overlay : allOverLays) {
			int oindex = overlay.getExtraInfo().getInt("type", -1);
			if (oindex > icons.size() - 1) {
				((Marker) overlay).setIcon(icons.get(icons.size() - 1));
			} else {
				((Marker) overlay).setIcon(icons.get(oindex - 1));
			}
		}

		// 改变当前marker状态
		if (index != -1) {
			if (index <= clicked_icons.size() - 1) {
				marker.setIcon(clicked_icons.get(index - 1));
			} else {
				marker.setIcon(clicked_icons.get(clicked_icons.size() - 1));
			}
		}
		if (mPopupWindow != null && mPopupWindow.isShowing()) {
			mPopupWindow.dismiss();
		}

		// ----------start---2014-09-03

		if (mPopupWindow != null && !mPopupWindow.isShowing()) {

			// 屏幕宽、高、密度
			DisplayMetrics metric = new DisplayMetrics();
			getWindowManager().getDefaultDisplay().getMetrics(metric);
			int height = metric.heightPixels; // 屏幕高度（像素）
			// 求图片宽、高
			int wid = DipPxUtils.dpToPxInt(this, 50.0f);
			int hei = DipPxUtils.dpToPxInt(this, 40.0f);

			String data = "<html><head>" + "<style type=\"text/css\">"
					+ "#divimg img{padding-right:10px;padding-bottom:2px;float:left;width:%spx;height:%spx;}"
					+ "</style>" + "</head>" + "<body>" + "<div id='divimg'>" + "<img src=\"" + url + "\">"
					+ "<font size=\"4px\">" + title.trim() + "</font>" + "<br/>" + desc.trim() + "</div></body></html>";

			String mData = String.format(data, wid, hei);

			mPopupWindow.setData(mData);
			// mPopupWindow.showAsDropDown(mMapView, 0, -mPopupYOffset);
			mPopupWindow.showAsDropDown(mMapView, 0, -height / 2); // 设置popUpWindow显示的位置和高度。

		}
		return true;

		// ----------end---2014-09-03
	}

	/**
	 * 地图点击事件
	 */
	@Override
	public void onMapClick(LatLng latLng) {
		if (allOverLays != null && allOverLays.size() > 0 && icons != null && icons.size() > 0) {
			for (Overlay overlay : allOverLays) {
				int index = overlay.getExtraInfo().getInt("type", -1);
				if (index > icons.size() - 1) {
					((Marker) overlay).setIcon(icons.get(icons.size() - 1));
				} else {
					((Marker) overlay).setIcon(icons.get(index - 1));
				}
			}
		}
		if (mPopupWindow != null && mPopupWindow.isShowing()) {
			mPopupWindow.dismiss();
		}
		mBaidumap.hideInfoWindow();
	}

	@Override
	public boolean onMapPoiClick(MapPoi mapPoi) {
		return false;
	}

	/**
	 * 位置指针已转动角度
	 */
	private float predegree = 0;

	private SensorManager mSensorManager;

	private Sensor mMagnetometer;

	private Sensor mAccelerometer;

	private float[] mGravity = new float[3];

	private float[] mGeomagnetic = new float[3];

	@Override
	public void onSensorChanged(SensorEvent event) {

		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) mGravity = event.values;
		if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) mGeomagnetic = event.values;

		if (mGravity != null && mGeomagnetic != null) {
			float R[] = new float[9];
			float I[] = new float[9];
			boolean success = SensorManager.getRotationMatrix(R, I, mGravity, mGeomagnetic);
			if (success) {
				float orientation[] = new float[3];
				SensorManager.getOrientation(R, orientation);
				float azimut = orientation[0]; // orientation contains:
				// azimut, pitch and roll
				predegree = (float) Math.toDegrees(azimut);
				if (mBaidumap != null && selfOverlay != null && mCurrentLocation != null) {
					((Marker) selfOverlay).setRotate(-predegree);
					LatLng ll = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude());
					((Marker) selfOverlay).setPosition(ll);
				}
			}
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

	/**
	 * 百度定位回调
	 */
	public class MyBDLocationListener implements BDLocationListener {

		@Override
		public void onReceiveLocation(final BDLocation location) {
			// Receive Location
			if (location == null || mMapView == null) {
				return;
			}
			mCurrentLocation = location;
			if (mBaidumap != null) {
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						if (!isAdded) {
							addSelfOverlay(new LatLng(location.getLatitude(), location.getLongitude()));
						}
					}
				}, 1000L);
			}

			if (isFirstLoc) {
				// 如果是第一次定位可以在这里设置中心点
				// isFirstLoc = false;
				// LatLng ll = new LatLng(location.getLatitude(),
				// location.getLongitude());
				// MapStatusUpdate u = MapStatusUpdateFactory.newLatLng(ll);
				// mBaidumap.animateMapStatus(u);
			}
		}
	}

	// ----------start---2014-09-03
	/**
	 * 底部弹出描述信息
	 */
	private class DescriptionPopupWindow extends PopupWindow {
		View mContentView;
		// ImageLoader imageLoader;
		WebView content;

		private DescriptionPopupWindow(final Context context) {
			super(context);
			mContentView = LayoutInflater.from(context).inflate(R.layout.ll_popup_poi, null);
			setContentView(mContentView);
			setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
			setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);

			mContentView.findViewById(R.id.go_there).setVisibility(View.GONE);
			content = (WebView) mContentView.findViewById(R.id.content);
		}

		public void setData(/* String title, */String desc/* , String url */) {
			content.loadDataWithBaseURL(null, desc, "text/html", "utf-8", null);

		}
	}

	// ----------end---2014-09-03

	/**
	 * life-cycle handle
	 */
	@Override
	protected void onPause() {
		super.onPause();
		mMapView.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		mSensorManager.registerListener(this, mAccelerometer, SensorManager.SENSOR_DELAY_NORMAL);
		mSensorManager.registerListener(this, mMagnetometer, SensorManager.SENSOR_DELAY_NORMAL);
		mMapView.onResume();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		AndroidUtils.hideProgress();
		// unbindService(mConnection);
		mLocationClient.stop();
		// selfOverlay = null;
		mSensorManager.unregisterListener(this);
		mBaidumap.setMyLocationEnabled(false);
		mMapView.onDestroy();
		mMapView = null;
		if (mRouteSearch != null) {
			mRouteSearch.destroy();
			mRouteSearch = null;
		}
		if (mPopupWindow != null && mPopupWindow.isShowing()) {
			mPopupWindow.dismiss();
		}
		// if (selfIcon != null) {
		// selfIcon.recycle();
		// }

		if (icons != null) {
			for (BitmapDescriptor bitmapDescriptor : icons) {
				bitmapDescriptor.recycle();
			}
		}
		if (clicked_icons != null) {
			for (BitmapDescriptor bitmapDescriptor : clicked_icons) {
				bitmapDescriptor.recycle();
			}
		}

		super.onDestroy();
	}

	// 路线规划
	private void routePlan() {
		LatLng startPoint;
		LatLng endPoint;
		if (mCurrentLocation != null) {
			startPoint = new LatLng(mCurrentLocation.getLatitude(), mCurrentLocation.getLongitude());
		} else {
			ToastUtils.show(this, "正在定位请稍等...");
			return;
		}
		if (mDestinationPoint != null) {
			endPoint = mDestinationPoint;
		} else {
			ToastUtils.show(this, "目的地地址有误...");
			return;
		}
		PlanNode startNode = PlanNode.withLocation(startPoint);
		PlanNode endNode = PlanNode.withLocation(endPoint);
		mRouteSearch.walkingSearch(new WalkingRoutePlanOption().from(startNode).to(endNode));
	}

	@Override
	public void onGetWalkingRouteResult(WalkingRouteResult walkingRouteResult) {
		AndroidUtils.hideProgress();
		if (walkingRouteResult == null || walkingRouteResult.error != SearchResult.ERRORNO.NO_ERROR) {
			return;
		}

		if (walkingRouteResult.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
			// 起终点或途经点地址有岐义，通过以下接口获取建议查询信息
			// result.getSuggestAddrInfo()
			return;
		}

		if (walkingRouteResult.error == SearchResult.ERRORNO.NO_ERROR) {
			// RouteLine mRoute = transitRouteResult.getRouteLines().get(0);
			WalkingRouteOverlay overlay = new WalkingRouteOverlay(mBaidumap);
			mBaidumap.setOnMarkerClickListener(overlay);
			overlay.setData(walkingRouteResult.getRouteLines().get(0));
			overlay.addToMap();
			overlay.zoomToSpan();
		}
	}

	@Override
	public void onGetTransitRouteResult(TransitRouteResult transitRouteResult) {

	}

	@Override
	public void onGetDrivingRouteResult(DrivingRouteResult drivingRouteResult) {

	}
}