package com.XJTUniversity.JDStudentPush;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.view.View;
import android.view.Window;
import android.widget.Toast;
import com.XJTUniversity.JDStudentPush.util.AndroidUtils;
import com.XJTUniversity.JDStudentPush.util.RequestManager;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;

/**
 * Created by vincent on 2014/6/23.<br/>
 * 描述: TODO
 */
public class LLBaseActivity extends FragmentActivity implements View.OnClickListener {

  protected Activity mActivity;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    requestWindowFeature(Window.FEATURE_NO_TITLE);
    mActivity = this;
  }

  @Override protected void onStop() {
    super.onStop();
    AndroidUtils.hideProgress();
    RequestManager.cancelAll(this);
  }

  protected void executeRequest(Request<?> request) {
    System.out.println("in parent execute");
    if (!App.isRefresh) {
      AndroidUtils.showProgress(mActivity);
    }
    RequestManager.addRequest(request, this);
  }

  protected Response.ErrorListener errorListener() {
    return new Response.ErrorListener() {
      @Override public void onErrorResponse(VolleyError volleyError) {
        App.isRefresh = false;
        AndroidUtils.hideProgress();
        Toast.makeText(mActivity, volleyError.getMessage(), Toast.LENGTH_SHORT).show();
      }
    };
  }

  @Override public void onClick(View v) {

  }
}
