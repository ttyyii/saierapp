package com.XJTUniversity.JDStudentPush;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import cn.jpush.android.api.JPushInterface;
import cn.jpush.android.api.TagAliasCallback;
import com.XJTUniversity.JDStudentPush.model.Login;
import com.XJTUniversity.JDStudentPush.util.AndroidUtils;
import com.XJTUniversity.JDStudentPush.util.Api;
import com.XJTUniversity.JDStudentPush.util.GsonRequest;
import com.XJTUniversity.JDStudentPush.util.PreferencesUtils;
import com.XJTUniversity.JDStudentPush.util.ToastUtils;
import com.android.volley.Response;
import java.util.Set;

/**
 * Created by vincent on 2014/6/23.<br/>
 * 描述: 登录页面
 */
public class LLLoginActivity extends LLBaseActivity {

  private TextView mLogo_text;
  private EditText mUname_edit;
  private EditText mPwd_edit;
  private CheckBox mAuto_login;
  private CheckBox mRemember_pwd;
  private ImageView mLogin_btn;
  private ImageView mFoget_pwd;
  private ImageView mReg;

  private boolean isAutoLogin;

  private boolean isRememberPwd;

  @Override protected void onCreate(Bundle savedInstanceState) {
    super.onCreate(savedInstanceState);
    setContentView(R.layout.ll_login_activity_layout);

    isAutoLogin = PreferencesUtils.getBoolean(this, App.AUTO_LOGIN);
    isRememberPwd = PreferencesUtils.getBoolean(this, App.REM_PWD);
    bindViews();
  }
  
  private void bindViews() {
    findViewById(R.id.title_logo).setVisibility(View.VISIBLE);
    mLogo_text = (TextView) findViewById(R.id.logo_text);
    mUname_edit = (EditText) findViewById(R.id.uname_edit);
    mPwd_edit = (EditText) findViewById(R.id.pwd_edit);
    mAuto_login = (CheckBox) findViewById(R.id.auto_login);
    mRemember_pwd = (CheckBox) findViewById(R.id.remember_pwd);
    mLogin_btn = (ImageView) findViewById(R.id.login_btn);
    mFoget_pwd = (ImageView) findViewById(R.id.foget_pwd);
    mReg = (ImageView) findViewById(R.id.reg);

    mAuto_login.setChecked(isAutoLogin);
    mRemember_pwd.setChecked(isRememberPwd);

    mReg.setOnClickListener(this);
    mAuto_login.setOnCheckedChangeListener(new MyCheckEvent());
    mRemember_pwd.setOnCheckedChangeListener(new MyCheckEvent());
    mFoget_pwd.setOnClickListener(this);
    mReg.setOnClickListener(this);
    mLogin_btn.setOnClickListener(this);

    if (isRememberPwd) {
      String uname = PreferencesUtils.getString(this, App.UNAME);
      String pwd = PreferencesUtils.getString(this, App.PWD);
      mUname_edit.setText(uname);
      mPwd_edit.setText(pwd);
    }

    if (isAutoLogin) {
      mLogin_btn.performClick();
    }
  }

  @Override public void onClick(View v) {
    if (v == mLogin_btn) {
      final String uname = mUname_edit.getText().toString();
      final String pwd = mPwd_edit.getText().toString();

      if (TextUtils.isEmpty(uname) || TextUtils.isEmpty(pwd)) {
        ToastUtils.show(this, getString(R.string.uname_cant_empty));
        return;
      }
      String url = String.format(Api.LOGIN_URL, uname, pwd);
      executeRequest(new GsonRequest<Login>(url, Login.class, new Response.Listener<Login>() {
        @Override public void onResponse(Login login) {
          AndroidUtils.hideProgress();
          if (login.isSuccess()) {
            //登录成功
            App.NET_ID = login.getUserId();

            if (mRemember_pwd.isChecked()) {
              PreferencesUtils.putString(mActivity, App.UNAME, uname);
              PreferencesUtils.putString(mActivity, App.PWD, pwd);
            }
            //Set Jpush Alias
            //if (!PreferencesUtils.getBoolean(mActivity, "hasAlias")) {
              setAlias(uname);
            //}

            Intent intent = new Intent(LLLoginActivity.this, LLMsgActivity.class);
            startActivity(intent);
            finish();
          }

          ToastUtils.show(mActivity, login.getMsg());
        }
      }, errorListener()));
    } else if (v == mFoget_pwd) {
      Intent intent = new Intent(this, LLAuthActivity.class);
      intent.putExtra("to", "topwd");
      startActivity(intent);
    } else if (v == mReg) {
      Intent intent = new Intent(this, LLAuthActivity.class);
      intent.putExtra("to", "toreg");
      startActivity(intent);
    }
  }

  private class MyCheckEvent implements CompoundButton.OnCheckedChangeListener {

    @Override public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
      int id = buttonView.getId();
      if (id == R.id.auto_login) {
        if (isChecked) {
          mRemember_pwd.setChecked(true);
        }
        PreferencesUtils.putBoolean(mActivity, App.AUTO_LOGIN, isChecked);
      } else if (id == R.id.remember_pwd) {
        if (!isChecked) {
          mAuto_login.setChecked(false);
        }
        PreferencesUtils.putBoolean(mActivity, App.REM_PWD, isChecked);
      }
    }
  }

  /** JPUSH set Alias* */
  private static final int MSG_SET_ALIAS = 1001;
  private final Handler mHandler = new Handler() {
    @Override
    public void handleMessage(android.os.Message msg) {
      super.handleMessage(msg);
      switch (msg.what) {
        case MSG_SET_ALIAS:
          // 调用 JPush 接口来设置别名。
          JPushInterface.setAliasAndTags(getApplicationContext(), (String) msg.obj, null,
              mAliasCallback);
          break;
        default:
      }
    }
  };

  private final TagAliasCallback mAliasCallback = new TagAliasCallback() {
    @Override
    public void gotResult(int code, String alias, Set<String> tags) {
      switch (code) {
        case 0:
          // 建议这里往 SharePreference 里写一个成功设置的状态。成功设置一次后，以后不必再次设置了。
          System.out.println("jpush alias set ok --->" + alias);
          PreferencesUtils.putBoolean(mActivity, "hasAlias", true);
          break;
        case 6002:
          // 延迟 60 秒来调用 Handler 设置别名
          System.out.println("jpush alias set faild --->" + alias);
          mHandler.sendMessageDelayed(mHandler.obtainMessage(MSG_SET_ALIAS, alias), 1000 * 60);
          break;
        default:
      }
    }
  };

  /**
   * set Jpush Alias
   */
  private void setAlias(String alias) {
    if (!AndroidUtils.isValidTagAndAlias(alias)) {
      Log.e(LLLoginActivity.class.getSimpleName(), "invalid jpush alias");
      return;
    }
    // 调用 Handler 来异步设置别名
    mHandler.sendMessage(mHandler.obtainMessage(MSG_SET_ALIAS, alias));
  }

  @Override protected void onStop() {
    super.onStop();
  }

  @Override protected void onDestroy() {
    AndroidUtils.hideProgress();
    if (TextUtils.isEmpty(mUname_edit.getText().toString()) ||
        TextUtils.isEmpty(mPwd_edit.getText().toString())) {
      PreferencesUtils.putBoolean(mActivity, App.AUTO_LOGIN, false);
      PreferencesUtils.putBoolean(mActivity, App.REM_PWD, false);
    }
    super.onDestroy();
  }
}