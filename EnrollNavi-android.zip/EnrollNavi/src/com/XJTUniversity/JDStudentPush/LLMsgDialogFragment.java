package com.XJTUniversity.JDStudentPush;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.support.v4.app.FragmentActivity;
import android.text.TextUtils;
import android.text.method.LinkMovementMethod;
import android.text.util.Linkify;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.webkit.HttpAuthHandler;
import android.webkit.SslErrorHandler;
import android.webkit.WebChromeClient;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;
import eu.inmite.android.lib.dialogs.ISimpleDialogListener;
import eu.inmite.android.lib.dialogs.SimpleDialogFragment;

/**
 * Created by vincent on 2014/6/25.<br/>
 * 描述: TODO
 */
public class LLMsgDialogFragment extends SimpleDialogFragment {

	public static void show(FragmentActivity activity, String msg, String type) {
		LLMsgDialogFragment fragment = new LLMsgDialogFragment();
		Bundle args = new Bundle();
		args.putString("msg", msg);
		args.putString("type", type);
		fragment.setArguments(args);
		fragment.show(activity.getSupportFragmentManager(), "msg-dialog");
	}

	@Override
	protected Builder build(final Builder builder) {
		View view = LayoutInflater.from(getActivity()).inflate(
				R.layout.ll_msg_dailog_layout, null);
		TextView msg = (TextView) view.findViewById(R.id.msg_text);
		TextView detail = (TextView) view.findViewById(R.id.detail_btn);
		ImageView close = (ImageView) view.findViewById(R.id.close_btn);

		String type = getArguments().getString("type");
		String message = getArguments().getString("msg");
		if (TextUtils.isEmpty(type)) {
			type = "0";
		}

		final int requestCode = Integer.parseInt(type);

		if (type.equals("1") || type.equals("2")) {
			detail.setVisibility(View.GONE);
		} else {
			detail.setVisibility(View.VISIBLE);
		}

		builder.setView(view);

		// ----------start---2014-09-02
		// message = matcherAndReplace(message);
		// msg.setMovementMethod(LinkMovementMethod.getInstance());
		// msg.setAutoLinkMask(0);
		Pattern pattern = Pattern
				.compile("(http://|ftp://|https://|www){0,1}[^\u4e00-\u9fa5\\s]*?\\.(com|net|cn|me|tw|fr)[^\u4e00-\u9fa5\\s]*");
		Matcher matcher = pattern.matcher(message);
		while (matcher.find()) {
			System.out.println(matcher.group(0));
			if (matcher.group(0).startsWith(":")) {
				String url = matcher.group(0).substring(1);
				url = url.trim();
				if (!url.startsWith("http://")) {
					url = "http://" + url;
				}
				message = message
						.replaceAll(
								"(http://|ftp://|https://|www){0,1}[^\u4e00-\u9fa5\\s]*?\\.(com|net|cn|me|tw|fr)[^\u4e00-\u9fa5\\s]*",
								url);
				Linkify.addLinks(msg, pattern, url);
			}
		}
		// ----------end-----2014-09-02

		msg.setText(message);

		final ISimpleDialogListener listener = getDialogListener();
		// final ISimpleDialogCancelListener cancelListener =
		// getCancelListener();
		detail.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				listener.onPositiveButtonClicked(requestCode);
				dismiss();
			}
		});

		close.setOnClickListener(new View.OnClickListener() {
			@Override
			public void onClick(View v) {
				dismiss();
			}
		});

		return builder;
	}

}
