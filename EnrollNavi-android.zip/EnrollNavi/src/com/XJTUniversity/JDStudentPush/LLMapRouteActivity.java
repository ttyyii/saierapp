package com.XJTUniversity.JDStudentPush;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.os.Handler;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.widget.PopupWindow;
import com.XJTUniversity.JDStudentPush.model.CampusInfo;
import com.XJTUniversity.JDStudentPush.model.ReportMaps;
import com.XJTUniversity.JDStudentPush.model.RoutesInfo;
import com.XJTUniversity.JDStudentPush.util.AndroidUtils;
import com.XJTUniversity.JDStudentPush.util.Api;
import com.XJTUniversity.JDStudentPush.util.DipPxUtils;
import com.XJTUniversity.JDStudentPush.util.GsonRequest;
import com.XJTUniversity.JDStudentPush.util.ToastUtils;
import com.android.volley.Response;
import com.baidu.location.BDLocation;
import com.baidu.location.BDLocationListener;
import com.baidu.location.LocationClient;
import com.baidu.location.LocationClientOption;
import com.baidu.mapapi.map.BaiduMap;
import com.baidu.mapapi.map.BitmapDescriptor;
import com.baidu.mapapi.map.BitmapDescriptorFactory;
import com.baidu.mapapi.map.MapPoi;
import com.baidu.mapapi.map.MapStatusUpdate;
import com.baidu.mapapi.map.MapStatusUpdateFactory;
import com.baidu.mapapi.map.MapView;
import com.baidu.mapapi.map.Marker;
import com.baidu.mapapi.map.MarkerOptions;
import com.baidu.mapapi.map.Overlay;
import com.baidu.mapapi.map.OverlayOptions;
import com.baidu.mapapi.model.LatLng;
import com.baidu.mapapi.overlayutil.OverlayManager;
import com.baidu.mapapi.overlayutil.TransitRouteOverlay;
import com.baidu.mapapi.overlayutil.WalkingRouteOverlay;
import com.baidu.mapapi.search.core.SearchResult;
import com.baidu.mapapi.search.route.DrivingRouteResult;
import com.baidu.mapapi.search.route.OnGetRoutePlanResultListener;
import com.baidu.mapapi.search.route.PlanNode;
import com.baidu.mapapi.search.route.RoutePlanSearch;
import com.baidu.mapapi.search.route.TransitRoutePlanOption;
import com.baidu.mapapi.search.route.TransitRouteResult;
import com.baidu.mapapi.search.route.WalkingRouteLine;
import com.baidu.mapapi.search.route.WalkingRoutePlanOption;
import com.baidu.mapapi.search.route.WalkingRouteResult;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by vincent on 2014/6/19.<br/>
 * 描述: TODO
 */
public class LLMapRouteActivity extends LLBaseActivity implements
		OnGetRoutePlanResultListener, BaiduMap.OnMapClickListener,
		SensorEventListener, BaiduMap.OnMarkerClickListener {

	private MapView mMapView;

	private BaiduMap mBaidumap;

	private LocationClient mLocationClient;

	private boolean isFirstLoc = true;

	private RoutePlanSearch mRouteSearch;

	private DescriptionPopupWindow mPopupWindow;

	private int mPopupYOffset;

	private String typeMarker = "";

	private int type;

	private OverlayManager mRouteOverlay;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ll_map_layout);

		mSensorManager = (SensorManager) getSystemService(SENSOR_SERVICE);
		mAccelerometer = mSensorManager
				.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
		mMagnetometer = mSensorManager
				.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
		
		mPopupWindow = new DescriptionPopupWindow(this);
		mPopupWindow.setBackgroundDrawable(null);
		mPopupYOffset = getResources().getDrawable(R.drawable.ll_view_pop)
				.getIntrinsicHeight();

		mRouteSearch = RoutePlanSearch.newInstance();
		mRouteSearch.setOnGetRoutePlanResultListener(this);
		initMap();
	}

	/**
	 * 初始化地图
	 */

	// 校园地图自身位置扎点图标
	private void initMap() {
		findViewById(R.id.title_layout).setVisibility(View.GONE);
		mMapView = (MapView) findViewById(R.id.bd_mapview);
		mBaidumap = mMapView.getMap();
		mBaidumap.setMapType(BaiduMap.MAP_TYPE_NORMAL);
		// mBaidumap.setTrafficEnabled(true);
		mBaidumap.setMapStatus(MapStatusUpdateFactory.zoomTo(17.0f));
		mBaidumap.setMapStatus(MapStatusUpdateFactory.newLatLng(new LatLng(
				34.253834, 108.990209)));
		// mBaidumap.setMyLocationEnabled(true);
		mBaidumap.setOnMapClickListener(this);
		// mBaidumap.setMyLocationConfigeration(
		// new
		// MyLocationConfigeration(MyLocationConfigeration.LocationMode.NORMAL,
		// true, selfIcon));
		// marker点击事件
		mBaidumap.setOnMarkerClickListener(this);
		mBaidumap.setOnMapLoadedCallback(new BaiduMap.OnMapLoadedCallback() {
			@Override
			public void onMapLoaded() {
				getMyPositionOnMap();
				type = getIntent().getIntExtra("type", 0);
				if (type == 4) {
					// 规划路径
					getRoutePoint();
				} else if (type == 3 || type == 5) {
					// 校园扎点
					getCampusPoint();
				}
			}
		});
	}

	/**
	 * 定位
	 */
	private void getMyPositionOnMap() {
		mLocationClient = ((App) getApplication()).mBDLocationClient;
		mLocationClient.registerLocationListener(new MyBDLocationListener());
		LocationClientOption option = new LocationClientOption();
		option.setOpenGps(true);
		option.setCoorType("bd09ll");
		option.setScanSpan(1000);
		option.setNeedDeviceDirect(true);
		mLocationClient.setLocOption(option);
		mLocationClient.start();
	}

	/**
	 * 获取起始点和和终点
	 */
	private void getRoutePoint() {
		String msgid = getIntent().getStringExtra("msgid");
		String url;
		if (!TextUtils.isEmpty(msgid)) {
			url = String.format(Api.ROUTE_INFO_URL, App.NET_ID, msgid);
			executeRequest(new GsonRequest<RoutesInfo>(url, RoutesInfo.class,
					new Response.Listener<RoutesInfo>() {
						@Override
						public void onResponse(RoutesInfo routesInfo) {
							hasLoadFinish = true;
							if (routesInfo != null && routesInfo.isSuccess()) {
								String sLatStr = routesInfo.getStartlat();
								String sLonStr = routesInfo.getStartLng();
								String eLatStr = routesInfo.getEndlat();
								String eLonStr = routesInfo.getEndLng();

								typeMarker = routesInfo.getReportMark();

								if (TextUtils.isEmpty(sLatStr)
										|| TextUtils.isEmpty(sLonStr)
										|| TextUtils.isEmpty(eLatStr)
										|| TextUtils.isEmpty(eLonStr)) {
									AndroidUtils.hideProgress();
									return;
								}
								LatLng sPoint = new LatLng(
										Double.parseDouble(sLatStr),
										Double.parseDouble(sLonStr));
								LatLng ePoint = new LatLng(
										Double.parseDouble(eLatStr),
										Double.parseDouble(eLonStr));
								routePlan(sPoint, ePoint);
							} else {
								AndroidUtils.hideProgress();
							}
						}
					}, errorListener()));
		}
	}

	/**
	 * 请求校园点数据
	 */
	private void getCampusPoint() {
		String msgid = getIntent().getStringExtra("msgid");
		String url = "";
		if (!TextUtils.isEmpty(msgid)) {
			if (type == 3) {
				url = String.format(Api.CAMPUS_INFO_URL, App.NET_ID, msgid);
			} else if (type == 5) {
				url = String.format(Api.MSG_TYPE_FIVE_URL, msgid);
			}
		}
		executeRequest(new GsonRequest<CampusInfo>(url, CampusInfo.class,
				new Response.Listener<CampusInfo>() {
					@Override
					public void onResponse(CampusInfo campusInfo) {
						if (campusInfo != null) {

							if (!TextUtils.isEmpty(campusInfo.getCampusLat())
									&& !TextUtils.isEmpty(campusInfo
											.getCampusLog())) {
								double cLat = Double.parseDouble(campusInfo
										.getCampusLat());
								double clng = Double.parseDouble(campusInfo
										.getCampusLog());

								LatLng ll = new LatLng(cLat, clng);
								MapStatusUpdate u = MapStatusUpdateFactory
										.newLatLng(ll);
								mBaidumap.animateMapStatus(u);
							} else if (campusInfo.getReportMaps() != null
									&& campusInfo.getReportMaps().size() > 0
									&& campusInfo.getReportMaps().get(0) != null) {
								ReportMaps point = campusInfo.getReportMaps()
										.get(0);
								if (!TextUtils.isEmpty(point.getReportMapLat())
										&& !TextUtils.isEmpty(point
												.getReportMapLng())) {
									double cLat = Double.parseDouble(point
											.getReportMapLat());
									double clng = Double.parseDouble(point
											.getReportMapLng());

									LatLng ll = new LatLng(cLat, clng);
									MapStatusUpdate u = MapStatusUpdateFactory
											.newLatLng(ll);
									mBaidumap.animateMapStatus(u);
								}
							}

							if (campusInfo.getReportMaps() != null
									&& campusInfo.getReportMaps().size() > 0) {
								initOverlay(campusInfo.getReportMaps());
							}
						}
						AndroidUtils.hideProgress();
					}
				}, errorListener()));
	}

	/**
	 * 初始化扎点
	 */

	// 校园地图扎点图标
	private ArrayList<BitmapDescriptor> bitmaps;
	private List<BitmapDescriptor> clickBitmaps;
	private ArrayList<Overlay> allOverlay;

	private void initOverlay(List<ReportMaps> points) {
		if (points == null || points.size() <= 0) {
			return;
		}
		bitmaps = new ArrayList<BitmapDescriptor>();
		clickBitmaps = new ArrayList<BitmapDescriptor>();
		bitmaps.addAll(AndroidUtils.getIconList(AndroidUtils.resIds.length));
		clickBitmaps.addAll(AndroidUtils
				.getClickedIconList(AndroidUtils.resIds_clicked.length));
		allOverlay = new ArrayList<Overlay>();
		mBaidumap.clear();
		for (ReportMaps p : points) {
			if (TextUtils.isEmpty(p.getReportMapLat())
					|| TextUtils.isEmpty(p.getReportMapLng())) {
				continue;
			}

			double lat = Double.parseDouble(p.getReportMapLat());
			double lon = Double.parseDouble(p.getReportMapLng());
			LatLng pos = new LatLng(lat, lon);
			Bundle b = new Bundle();
			b.putString("title", p.getReportMapTitle());
			b.putString("desc", p.getReportMapDesc());
			b.putString("url", p.getReportMapPic());
			b.putString("ztype", "llsoft");
			int index = p.getReportMapIndex();
			BitmapDescriptor markerIcon = null;
			if (!TextUtils.isEmpty(index + "")
					&& TextUtils.isDigitsOnly(index + "")
					&& index <= bitmaps.size() - 1) {
				markerIcon = bitmaps.get(index - 1);
			} else {
				markerIcon = bitmaps.get(bitmaps.size() - 1);
			}
			b.putInt("index", index);
			OverlayOptions oo = new MarkerOptions().position(pos)
					.icon(markerIcon).extraInfo(b);
			Overlay marker = mBaidumap.addOverlay(oo);
			allOverlay.add(marker);
		}
		hasLoadFinish = true;
	}

	private void routePlan(LatLng startPoint, LatLng endPoint) {
		PlanNode startNode = PlanNode.withLocation(startPoint);
		PlanNode endNode = PlanNode.withLocation(endPoint);
		mRouteSearch.transitSearch(new TransitRoutePlanOption().from(startNode)
				.city("西安市").to(endNode));
	}

	/*
	 * 步行路线
	 */
	private List<WalkingRouteLine.WalkingStep> mSteps;

	@Override
	public void onGetWalkingRouteResult(WalkingRouteResult walkingRouteResult) {
		AndroidUtils.hideProgress();
		mSteps = new ArrayList<WalkingRouteLine.WalkingStep>();
		if (walkingRouteResult == null
				|| walkingRouteResult.error != SearchResult.ERRORNO.NO_ERROR) {
			return;
		}

		if (walkingRouteResult.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
			// 起终点或途经点地址有岐义，通过以下接口获取建议查询信息
			// result.getSuggestAddrInfo()
			return;
		}

		if (walkingRouteResult.error == SearchResult.ERRORNO.NO_ERROR) {
			WalkingRouteOverlay overlay = new WalkingRouteOverlay(mBaidumap);
			mRouteOverlay = overlay;
			// mBaidumap.setOnMarkerClickListener(overlay);
			WalkingRouteLine line = walkingRouteResult.getRouteLines().get(0);
			overlay.setData(walkingRouteResult.getRouteLines().get(0));
			overlay.addToMap();
			overlay.zoomToSpan();
			mSteps.addAll(line.getAllStep());
		}
	}

	/**
	 * 公交路线
	 */
	@Override
	public void onGetTransitRouteResult(TransitRouteResult transitRouteResult) {
		if (transitRouteResult == null
				|| transitRouteResult.error != SearchResult.ERRORNO.NO_ERROR) {
			// 未找到结果
			AndroidUtils.hideProgress();
			return;
		}
		if (transitRouteResult.error == SearchResult.ERRORNO.AMBIGUOUS_ROURE_ADDR) {
			// 起终点或途经点地址有岐义，通过以下接口获取建议查询信息
			// result.getSuggestAddrInfo()
			AndroidUtils.hideProgress();
			return;
		}

		if (transitRouteResult.error == SearchResult.ERRORNO.NO_ERROR) {
			// RouteLine mRoute = transitRouteResult.getRouteLines().get(0);
			TransitRouteOverlay overlay = new TransitRouteOverlay(mBaidumap);
			mBaidumap.setOnMarkerClickListener(overlay);
			if (!TextUtils.isEmpty(typeMarker)
					&& typeMarker.equalsIgnoreCase("1003")) {
				overlay.setData(transitRouteResult.getRouteLines().get(1));
			} else {
				overlay.setData(transitRouteResult.getRouteLines().get(0));
			}
			overlay.addToMap();
			overlay.zoomToSpan();
			AndroidUtils.hideProgress();
		}
	}

	/**
	 * 驾车路线
	 */
	@Override
	public void onGetDrivingRouteResult(DrivingRouteResult drivingRouteResult) {
	}

	/**
	 * marker点击事件
	 */
	private LatLng mDestinationPoint;

	@Override
	public boolean onMarkerClick(Marker marker) {
		if (marker.getExtraInfo() == null) {
			return true;
		}
		mDestinationPoint = marker.getPosition();
		String type = marker.getExtraInfo().getString("ztype");
		String title = marker.getExtraInfo().getString("title");
		String desc = marker.getExtraInfo().getString("desc");
		String url = marker.getExtraInfo().getString("url");
		int index = marker.getExtraInfo().getInt("index", -1);
		if (TextUtils.isEmpty(type) && mSteps != null && mSteps.size() > 0) {
			ToastUtils.show(this, mSteps.get(index - 1).getInstructions());
			return true;
		}
		if (index != -1) {
			if (index > clickBitmaps.size() - 1) {
				marker.setIcon(clickBitmaps.get(clickBitmaps.size() - 1));
			} else {
				marker.setIcon(clickBitmaps.get(index - 1));
			}
			for (Overlay overlay : allOverlay) {
				Marker otherMarker = ((Marker) overlay);
				int oindex = otherMarker.getExtraInfo().getInt("index", -1);
				if (oindex == index) {
					continue;
				}
				if (oindex != -1 && oindex <= bitmaps.size() - 1) {
					otherMarker.setIcon(bitmaps.get(oindex - 1));
				} else {
					otherMarker.setIcon(bitmaps.get(bitmaps.size() - 1));
				}
			}
		}

		if (mPopupWindow != null && mPopupWindow.isShowing()) {
			mPopupWindow.dismiss();
		}

		if (mPopupWindow != null && !mPopupWindow.isShowing()) {
      // 屏幕宽、高、密度
      DisplayMetrics metric = new DisplayMetrics();
      getWindowManager().getDefaultDisplay().getMetrics(metric);
      int height = metric.heightPixels; // 屏幕高度（像素）
      // 求图片宽、高
      int wid = DipPxUtils.dpToPxInt(this, 50.0f);
      int hei = DipPxUtils.dpToPxInt(this, 40.0f);

      String data = "<html><head>" + "<style type=\"text/css\">"
          + "#divimg img{padding-right:10px;padding-bottom:2px;float:left;width:%spx;height:%spx;}"
          + "</style>" + "</head>" + "<body>" + "<div id='divimg'>" + "<img src=\"" + url + "\">"
          + "<font size=\"4px\">" + title.trim() + "</font>" + "<br/>" + desc.trim() + "</div></body></html>";

      String mData = String.format(data, wid, hei);

			mPopupWindow.setData(mData);

			mPopupWindow.showAsDropDown(mMapView, 0, -height / 2);
		}
		return true;
	}

	@Override
	public void onMapClick(LatLng latLng) {
		if (allOverlay != null && allOverlay.size() > 0) {

			for (Overlay overlay : allOverlay) {
				Marker otherMarker = ((Marker) overlay);
				int oindex = otherMarker.getExtraInfo().getInt("index", -1);
				if (oindex != -1 && oindex < bitmaps.size()) {
					otherMarker.setIcon(bitmaps.get(oindex - 1));
				} else {
					otherMarker.setIcon(bitmaps.get(bitmaps.size() - 1));
				}
			}
			if (mPopupWindow != null && mPopupWindow.isShowing()) {
				mPopupWindow.dismiss();
			}
		}
		mBaidumap.hideInfoWindow();
	}

	@Override
	public boolean onMapPoiClick(MapPoi mapPoi) {
		return false;
	}

	/**
	 * 位置指针已转动角度
	 */
	private float predegree = 0;

	private SensorManager mSensorManager;

	private Sensor mMagnetometer;

	private Sensor mAccelerometer;

	private float[] mGravity = new float[3];

	private float[] mGeomagnetic = new float[3];

	@Override
	public void onSensorChanged(SensorEvent event) {

		if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER)
			mGravity = event.values;
		if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD)
			mGeomagnetic = event.values;

		if (mGravity != null && mGeomagnetic != null) {
			float R[] = new float[9];
			float I[] = new float[9];
			boolean success = SensorManager.getRotationMatrix(R, I, mGravity,
					mGeomagnetic);
			if (success) {
				float orientation[] = new float[3];
				SensorManager.getOrientation(R, orientation);
				float azimut = orientation[0]; // orientation contains:
				predegree = (float) Math.toDegrees(azimut);
				if (mBaidumap != null && selfOverlay != null
						&& mCurrentLocation != null) {
					((Marker) selfOverlay).setRotate(-predegree);
					LatLng ll = new LatLng(mCurrentLocation.getLatitude(),
							mCurrentLocation.getLongitude());
					((Marker) selfOverlay).setPosition(ll);
				}
			}
		}
	}

	@Override
	public void onAccuracyChanged(Sensor sensor, int accuracy) {

	}

	private Handler mHandler = new Handler();
	private BDLocation mCurrentLocation;
	private boolean hasLoadFinish = false;

	/**
	 * 百度定位
	 */
	public class MyBDLocationListener implements BDLocationListener {

		@Override
		public void onReceiveLocation(final BDLocation location) {
			// Receive Location
			if (location == null || mMapView == null) {
				return;
			}

			mCurrentLocation = location;
			if (mBaidumap != null && hasLoadFinish) {
				mHandler.postDelayed(new Runnable() {
					@Override
					public void run() {
						if (!isAdded) {
							addSelfOverlay(new LatLng(location.getLatitude(),
									location.getLongitude()));
						}
					}
				}, 0L);
			}
		}

		// @Override
		// public void onReceivePoi(BDLocation arg0) {
		// }
	}

	private BitmapDescriptor selfIcon = BitmapDescriptorFactory
			.fromResource(R.drawable.ll_mylocation);
	private Overlay selfOverlay;
	private boolean isAdded = false;

	private void addSelfOverlay(LatLng latLng) {
		if (selfIcon == null) {
			selfIcon = BitmapDescriptorFactory
					.fromResource(R.drawable.ll_mylocation);
		}
		final OverlayOptions oo = new MarkerOptions().position(latLng)
				.icon(selfIcon).anchor(0.5f, 0.5f);
		try {
			selfOverlay = mBaidumap.addOverlay(oo);
		} catch (Exception e) {
			System.err.println(e.toString());
		}
		isAdded = true;
	}

	/**
	 * 底部弹出描述信息
	 */
	private class DescriptionPopupWindow extends PopupWindow {
		View mContentView;
		// ImageLoader imageLoader;
		WebView content;

		private DescriptionPopupWindow(final Context context) {
			super(context);
			mContentView = LayoutInflater.from(context).inflate(
					R.layout.ll_popup_poi, null);
			setContentView(mContentView);
			setWidth(ViewGroup.LayoutParams.MATCH_PARENT);
			setHeight(ViewGroup.LayoutParams.WRAP_CONTENT);
			// imageLoader = RequestManager.getImageLoader();
			mContentView.findViewById(R.id.go_there).setOnClickListener(
					new View.OnClickListener() {
						@Override
						public void onClick(View v) {
							AndroidUtils.showProgress(context);
							routePlan();
							dismiss();
						}
					});
			content = (WebView) mContentView.findViewById(R.id.content);
		}

			// ((TextView) mContentView.findViewById(R.id.popup_tv_name))
			// .setText(title);
			// ((TextView)
			// mContentView.findViewById(R.id.popup_tv_content)).setText(desc);
			// NetworkImageView imageView = ((NetworkImageView)
			// mContentView.findViewById(R.id.popup_img));
			// imageView.setDefaultImageResId(R.drawable.ll_view_photos05);
			// if (TextUtils.isEmpty(url)) {
			// imageView.setErrorImageResId(R.drawable.ll_view_photos05);
			// imageView.setImageUrl(url, imageLoader);
			// }
		public void setData(/* String title, */String desc/* , String url */) {

			content.loadDataWithBaseURL(null, desc, "text/html", "utf-8", null);
		}
	}

	/**
	 * life-cycle handle
	 */
	@Override
	protected void onPause() {
		super.onPause();
		mMapView.onPause();
	}

	@Override
	protected void onResume() {
		super.onResume();
		mSensorManager.registerListener(this, mAccelerometer,
				SensorManager.SENSOR_DELAY_NORMAL);
		mSensorManager.registerListener(this, mMagnetometer,
				SensorManager.SENSOR_DELAY_NORMAL);
		mMapView.onResume();
	}

	@Override
	protected void onStop() {
		super.onStop();
	}

	@Override
	protected void onDestroy() {
		AndroidUtils.hideProgress();
		mSensorManager.unregisterListener(this);
		mLocationClient.stop();
		if (mPopupWindow != null && mPopupWindow.isShowing()) {
			mPopupWindow.dismiss();
		}
		mMapView.onDestroy();
		mMapView = null;
		if (mRouteSearch != null) {
			mRouteSearch.destroy();
			mRouteSearch = null;
		}
		// mBaidumap.setMyLocationEnabled(false);
		if (bitmaps != null) {
			for (BitmapDescriptor bitmapDescriptor : bitmaps) {
				bitmapDescriptor.recycle();
			}
		}
		if (clickBitmaps != null) {
			for (BitmapDescriptor bitmapDescriptor : clickBitmaps) {
				bitmapDescriptor.recycle();
			}
		}
		selfIcon.recycle();
		super.onDestroy();
	}

	// 路线规划
	private void routePlan() {
		if (mRouteOverlay != null) {
			mRouteOverlay.removeFromMap();
		}
		LatLng startPoint;
		LatLng endPoint;
		if (mCurrentLocation != null) {
			startPoint = new LatLng(mCurrentLocation.getLatitude(),
					mCurrentLocation.getLongitude());
		} else {
			ToastUtils.show(this, "正在定位请稍等...");
			return;
		}
		if (mDestinationPoint != null) {
			endPoint = mDestinationPoint;
		} else {
			ToastUtils.show(this, "目的地地址有误...");
			return;
		}
		PlanNode startNode = PlanNode.withLocation(startPoint);
		PlanNode endNode = PlanNode.withLocation(endPoint);
		mRouteSearch.walkingSearch(new WalkingRoutePlanOption().from(startNode)
				.to(endNode));
	}
}